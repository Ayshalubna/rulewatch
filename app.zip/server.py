"""RuleWatch production web server.

Serves the website (frontend/dist) and the API the website uses.

    uvicorn server:app --host 0.0.0.0 --port 8000   (or double-click start_web.bat on Windows)

Settings (environment variables / .env):
    ADMIN_TOKEN        if set, changing sources, companies, uploads, rule checks and quality tests
                       needs this token (the website asks for it once). Plan checks and questions stay public.
    PUBLIC_RATE_LIMIT  plan checks + questions allowed per visitor per hour (default 30)
"""
import os
import threading
import time
import uuid
from collections import defaultdict, deque
from collections import Counter
from pathlib import Path

from fastapi import FastAPI, File, Form, Header, HTTPException, Request, UploadFile
from fastapi.middleware.gzip import GZipMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from rulewatch import config, embed, llm, store
from rulewatch.agents import watcher
from rulewatch.manager import run_ask, run_check, run_watch
from rulewatch.scenarios import SCENARIOS

ADMIN_TOKEN = os.getenv("ADMIN_TOKEN", "").strip()
RATE = int(os.getenv("PUBLIC_RATE_LIMIT", "30"))
DIST = Path(__file__).parent / "frontend" / "dist"

app = FastAPI(title="RuleWatch API", version="1.0")
app.add_middleware(GZipMiddleware, minimum_size=800)
store.seed_sources(config.DEFAULT_SOURCES)

# ---------------- background runs ----------------
RUNS: dict[str, dict] = {}
_busy_lock = threading.Lock()
_heavy_running = {"kind": None}   # only one watcher / quality run at a time


def _start(kind: str, fn, heavy=False) -> str:
    run_id = uuid.uuid4().hex[:8]
    if heavy:
        with _busy_lock:
            if _heavy_running["kind"]:
                raise HTTPException(409, f"A {_heavy_running['kind']} is already running. Try again when it finishes.")
            _heavy_running["kind"] = kind
    RUNS[run_id] = {"kind": kind, "status": "running", "started": time.time(), "result": None, "error": None}

    def work():
        try:
            RUNS[run_id]["result"] = fn(run_id)
            RUNS[run_id]["status"] = "done"
        except Exception as e:  # shown to the user in the run panel, in plain words
            RUNS[run_id]["status"] = "error"
            raw = str(e)
            if "All AI models failed" in raw or "429" in raw:
                RUNS[run_id]["error"] = "The AI service is busy right now (free plan limit). Please try again in a minute."
            elif "connect" in raw.lower() or "timeout" in raw.lower():
                RUNS[run_id]["error"] = "RuleWatch could not reach the AI service. Check the internet connection and try again."
            else:
                RUNS[run_id]["error"] = "Something went wrong while running this. Please try again."
            store.log(run_id, "Manager", f"Stopped: {str(e)[:200]}")
        finally:
            RUNS[run_id]["finished"] = time.time()
            if heavy:
                _heavy_running["kind"] = None

    threading.Thread(target=work, daemon=True).start()
    if len(RUNS) > 300:  # forget old runs
        for k in sorted(RUNS, key=lambda k: RUNS[k]["started"])[:100]:
            RUNS.pop(k, None)
    return run_id


# ---------------- protection ----------------
_hits: dict[str, deque] = defaultdict(deque)


def _rate_limit(request: Request):
    ip = request.headers.get("x-forwarded-for", request.client.host if request.client else "?").split(",")[0]
    q, now = _hits[ip], time.time()
    while q and now - q[0] > 3600:
        q.popleft()
    if len(q) >= RATE:
        raise HTTPException(429, "Hourly limit reached for this visitor. Please try again later.")
    q.append(now)


def _admin(token: str | None):
    if ADMIN_TOKEN and token != ADMIN_TOKEN:
        raise HTTPException(401, "Admin access needed. Unlock admin mode with your admin token.")


# ---------------- models ----------------
class CheckIn(BaseModel):
    plan: str = Field(min_length=10, max_length=3000)
    company_type: str
    company_id: int | None = None
    lang: str = "en"


class AskIn(BaseModel):
    question: str = Field(min_length=3, max_length=1000)
    lang: str = "en"


class CompanyIn(BaseModel):
    name: str = Field(min_length=1, max_length=120)
    type: str
    activities: str = ""
    email: str = ""


class SourceIn(BaseModel):
    name: str
    regulator: str
    kind: str
    url: str
    follow: str | None = None


class WatchIn(BaseModel):
    max_new: int = Field(8, ge=1, le=40)


class QualityIn(BaseModel):
    n: int = Field(8, ge=1, le=len(SCENARIOS))


# ---------------- read endpoints ----------------
@app.get("/api/health")
def health():
    return {"ok": True}


@app.get("/api/meta")
def meta():
    s = store.stats()
    docs = store.list_documents(status="read")
    return {
        "business_types": [{"name": k, "topics": v} for k, v in config.COMPANY_TYPES.items()],
        "topics": config.TOPICS,
        "scenarios": SCENARIOS,
        "demo_mode": llm.is_mock(),
        "model": None if llm.is_mock() else config.LLM_MODEL,
        "admin_required": bool(ADMIN_TOKEN),
        "stats": {
            "documents": len(docs),
            "passages": s["chunks"],
            "characters": s["chars"],
            "regulators": sorted({d["regulator"] for d in docs}),
            "companies": len(store.list_companies()),
            "alerts": len(store.list_alerts()),
            "last_update": max((d.get("last_changed") or d["first_seen"] or "" for d in docs), default=None),
        },
    }


def _doc_view(d: dict, full=False) -> dict:
    keep = ["id", "title", "regulator", "url", "kind", "first_seen", "last_changed", "change_type", "severity",
            "topics", "summary_en", "summary_ar", "affects", "key_points"]
    out = {k: d.get(k) for k in keep}
    if not full:
        out["key_points"] = (d.get("key_points") or [])[:3]
    return out


@app.get("/api/rules")
def rules():
    return [_doc_view(d) for d in store.list_documents(status="read")]


@app.get("/api/rules/{doc_id}")
def rule(doc_id: int):
    d = store.get_document(doc_id)
    if not d or d["status"] != "read":
        raise HTTPException(404, "Rule document not found")
    return _doc_view(d, full=True)


@app.get("/api/companies")
def companies():
    return store.list_companies()


@app.get("/api/alerts")
def alerts():
    return store.list_alerts()[:100]


@app.get("/api/sources")
def sources():
    return store.list_sources()


@app.get("/api/quality")
def quality():
    docs = store.list_documents(status="read")
    topic_count = Counter(t for d in docs for t in d["topics"])
    coverage = [{"business_type": ct, "topics": [{"topic": t, "documents": topic_count.get(t, 0)} for t in topics]}
                for ct, topics in config.COMPANY_TYPES.items()]
    last = store.last_eval()
    return {"coverage": coverage, "topic_count": dict(topic_count),
            "last_eval": {"ts": last["ts"], "summary": last["results"][0]["summary"], "results": last["results"][1:]}
            if last else None}


@app.get("/api/activity")
def activity(limit: int = 60):
    return store.get_log(limit=min(limit, 300))


@app.get("/api/runs/{run_id}")
def run_status(run_id: str):
    r = RUNS.get(run_id)
    if not r:
        raise HTTPException(404, "Run not found")
    return {**{k: v for k, v in r.items()}, "log": store.get_log(run_id=run_id)}


# ---------------- actions ----------------
@app.post("/api/check")
def check(body: CheckIn, request: Request):
    _rate_limit(request)
    if body.company_type not in config.COMPANY_TYPES:
        raise HTTPException(400, "Unknown business type")
    activities = ""
    if body.company_id:
        c = next((c for c in store.list_companies() if c["id"] == body.company_id), None)
        activities = c["activities"] if c else ""
    rid = _start("plan check", lambda run_id: run_check(body.plan, body.company_type, activities,
                                                        body.lang, run_id=run_id))
    return {"run_id": rid}


@app.post("/api/ask")
def ask(body: AskIn, request: Request):
    _rate_limit(request)
    rid = _start("question", lambda run_id: run_ask(body.question, body.lang, run_id=run_id))
    return {"run_id": rid}


@app.post("/api/companies")
def add_company(body: CompanyIn, x_admin_token: str | None = Header(None)):
    _admin(x_admin_token)
    if body.type not in config.COMPANY_TYPES:
        raise HTTPException(400, "Unknown business type")
    return {"id": store.add_company(body.name.strip(), body.type, body.activities.strip(), body.email.strip())}


@app.delete("/api/companies/{company_id}")
def delete_company(company_id: int, x_admin_token: str | None = Header(None)):
    _admin(x_admin_token)
    store.delete_company(company_id)
    return {"ok": True}


@app.post("/api/sources")
def add_source(body: SourceIn, x_admin_token: str | None = Header(None)):
    _admin(x_admin_token)
    if not body.url.startswith("http") or body.kind not in ("document", "listing", "crawl"):
        raise HTTPException(400, "Give an http(s) link and a type: document, listing or crawl")
    store.add_source(body.name, body.regulator, body.kind, body.url, body.follow or None, body.kind == "crawl")
    return {"ok": True}


@app.patch("/api/sources/{source_id}")
def toggle_source(source_id: int, enabled: bool, x_admin_token: str | None = Header(None)):
    _admin(x_admin_token)
    store.set_source_enabled(source_id, enabled)
    return {"ok": True}


@app.post("/api/watch")
def watch(body: WatchIn, x_admin_token: str | None = Header(None)):
    _admin(x_admin_token)
    return {"run_id": _start("rule check", lambda run_id: _slim_watch(run_watch(max_new=body.max_new, run_id=run_id)),
                             heavy=True)}


def _slim_watch(r: dict) -> dict:
    return {"read": len(r.get("read_ids") or []), "alerts_sent": r.get("alerts_sent", 0)}


@app.post("/api/upload")
async def upload(files: list[UploadFile] = File(...), regulator: str = Form("DLD/RERA"), link: str = Form(""),
                 x_admin_token: str | None = Header(None)):
    _admin(x_admin_token)
    for f in files:
        data = await f.read()
        if not data.startswith(b"%PDF"):
            raise HTTPException(400, f"{f.filename} is not a PDF")
        watcher.add_local_pdf(data, f.filename, regulator, link if len(files) == 1 else "")
    return {"run_id": _start("upload", lambda run_id: _slim_watch(run_watch(skip_web=True, run_id=run_id)),
                             heavy=True)}


@app.post("/api/quality/run")
def quality_run(body: QualityIn, x_admin_token: str | None = Header(None)):
    _admin(x_admin_token)
    from rulewatch.evaluate import evaluate
    return {"run_id": _start("quality test", lambda run_id: evaluate(sample=body.n, run_id=run_id)["summary"],
                             heavy=True)}


@app.post("/api/admin/verify")
def verify_admin(x_admin_token: str | None = Header(None)):
    _admin(x_admin_token)
    return {"ok": True}


# ---------------- website ----------------
@app.on_event("startup")
def warm_up():
    threading.Thread(target=lambda: embed.embed(["warm up"]), daemon=True).start()


if (DIST / "assets").exists():
    app.mount("/assets", StaticFiles(directory=DIST / "assets"), name="assets")


@app.get("/{path:path}", include_in_schema=False)
def spa(path: str):
    if path.startswith("api/"):
        return JSONResponse({"detail": "Not found"}, status_code=404)
    f = DIST / path
    if path and f.is_file():
        return FileResponse(f)
    index = DIST / "index.html"
    if index.exists():
        return FileResponse(index)
    return JSONResponse({"detail": "Website not built yet. Run: cd frontend && npm install && npm run build"})
