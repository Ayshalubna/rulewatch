"""Run the daily rule check from the command line (used by Windows Task Scheduler).

    python watch.py
"""
from rulewatch.manager import run_watch
from rulewatch import store

if __name__ == "__main__":
    import sys
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    result = run_watch(max_new=5)
    for row in store.get_log(run_id=result["run_id"]):
        print(f"[{row['agent']}] {row['message']}")
