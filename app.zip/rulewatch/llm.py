"""One small wrapper for the AI model.

Works with any OpenAI-compatible API: Groq, OpenAI, Gemini, Ollama.
- Automatic fallback: if a model hits its daily limit or is not available, the next model is used.
- Short waits on per-minute limits.
- Answer cache: the same question gives the same answer instantly (saves free-tier limits during demos).
In mock mode (no key) each agent supplies its own fake answer, so the app can be tested offline.
"""
import hashlib
import json
import re
import threading
import time

from . import config

_client = None
_lock = threading.Lock()
_dead_until: dict[str, float] = {}   # model -> time until which we skip it
_cache: dict[str, dict] = {}
CACHE_MAX = 500
usage = {"calls": 0, "cache_hits": 0, "fallbacks": 0, "last_model": None}


def is_mock() -> bool:
    return config.LLM_PROVIDER == "mock" or not config.LLM_API_KEY


def _get_client():
    global _client
    if _client is None:
        from openai import OpenAI
        _client = OpenAI(api_key=config.LLM_API_KEY, base_url=config.LLM_BASE_URL, timeout=90)
    return _client


def _parse_json(text: str):
    text = re.sub(r"<think>.*?</think>", "", text or "", flags=re.S).strip()
    text = re.sub(r"^```(?:json)?|```$", "", text, flags=re.M).strip()
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        m = re.search(r"\{.*\}", text, flags=re.S)
        if m:
            return json.loads(m.group(0))
        raise


def _chain(fast: bool) -> list[str]:
    first = config.LLM_FAST_MODEL if fast else config.LLM_MODEL
    chain = [first] + [m for m in config.LLM_FALLBACK_MODELS if m != first]
    now = time.time()
    return [m for m in chain if _dead_until.get(m, 0) < now]


def _is_daily_limit(err: str) -> bool:
    e = err.lower()
    return ("per day" in e) or ("tokens per day" in e) or ("tpd" in e) or ("requests per day" in e) or ("rpd" in e)


def _is_model_problem(err: str) -> bool:
    e = err.lower()
    return any(w in e for w in ("model_not_found", "does not exist", "decommissioned", "not found",
                                "model_decommissioned", "not supported", "404"))


def chat_json(system: str, user: str, mock=None, temperature=0.1, retries=3, fast=False, cache=True) -> dict:
    """Ask the model and get back a JSON object (dict).
    fast=True uses the smaller model first (for bulk reading of long documents)."""
    if is_mock():
        return mock() if callable(mock) else (mock or {})

    key = hashlib.sha256(f"{fast}|{system}|{user}".encode()).hexdigest()
    if cache and key in _cache:
        usage["cache_hits"] += 1
        return _cache[key]
    if cache:
        try:
            from . import store
            hit = store.cache_get(key)
            if hit is not None:
                usage["cache_hits"] += 1
                _cache[key] = hit
                return hit
        except Exception:
            pass

    messages = [{"role": "system", "content": system + "\nAnswer ONLY with one valid JSON object."},
                {"role": "user", "content": user}]
    errors = []
    for round_no in range(3):   # if every model is only briefly rate-limited, wait and try the chain again
        out = _try_chain(fast, messages, temperature, retries, errors)
        if out is not None:
            if cache:
                with _lock:
                    if len(_cache) > CACHE_MAX:
                        _cache.clear()
                    _cache[key] = out
                try:
                    from . import store
                    store.cache_set(key, out)
                except Exception:
                    pass
            return out
        soonest = min((_dead_until.get(m, 0) for m in _all_models(fast)), default=0) - time.time()
        if soonest > 90 or round_no == 2:
            break
        time.sleep(max(5, soonest + 1))
    raise RuntimeError("All AI models failed. Last errors: " + " | ".join(errors[-3:]))


def _all_models(fast: bool) -> list[str]:
    first = config.LLM_FAST_MODEL if fast else config.LLM_MODEL
    return [first] + [m for m in config.LLM_FALLBACK_MODELS if m != first]


def _try_chain(fast, messages, temperature, retries, errors):
    for model in _chain(fast):
        use_json_mode = True
        for attempt in range(retries):
            try:
                kwargs = {"model": model, "temperature": temperature, "messages": messages}
                if use_json_mode:
                    kwargs["response_format"] = {"type": "json_object"}
                resp = _get_client().chat.completions.create(**kwargs)
                out = _parse_json(resp.choices[0].message.content)
                if not isinstance(out, dict):
                    raise ValueError("model did not return a JSON object")
                with _lock:
                    usage["calls"] += 1
                    usage["last_model"] = model
                return out
            except Exception as e:
                err = str(e)
                errors.append(f"{model}: {err[:160]}")
                if "429" in err or "rate" in err.lower():
                    if _is_daily_limit(err):
                        _dead_until[model] = time.time() + 3600   # skip this model for an hour
                        usage["fallbacks"] += 1
                        break
                    m = re.search(r"try again in (?:(\d+)m)?([\d.]+)s", err)
                    wait = (int(m.group(1) or 0) * 60 + float(m.group(2)) + 1) if m else 10 * (attempt + 1)
                    if wait > 45:   # long wait: faster to switch model
                        _dead_until[model] = time.time() + wait
                        usage["fallbacks"] += 1
                        break
                    time.sleep(wait)
                elif _is_model_problem(err):
                    _dead_until[model] = time.time() + 6 * 3600
                    usage["fallbacks"] += 1
                    break
                elif "response_format" in err or "json_validate" in err or "json" in err.lower() and "400" in err:
                    use_json_mode = False   # some models don't support JSON mode, or failed it once
                else:
                    time.sleep(2 * (attempt + 1))
    return None
