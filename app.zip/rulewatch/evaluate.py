"""QUALITY TEST: runs the scenario library through the full agent team and measures:

- signal accuracy   : does the overall signal match what a compliance officer would expect?
- citation rate     : do red/yellow warnings point to a real rule passage?
- topic hit         : did the Retriever find rules from the right topic?
- coverage gaps     : which topics have no rules loaded yet (so you know what to add next)

Run from the command line:   python -m rulewatch.evaluate        (or from the Quality tab)
"""
import random
import time

from . import store
from .manager import run_check
from .scenarios import SCENARIOS


def evaluate(sample: int | None = None, progress=None, run_id=None) -> dict:
    items = SCENARIOS if not sample else random.sample(SCENARIOS, min(sample, len(SCENARIOS)))
    results = []
    for i, sc in enumerate(items, start=1):
        if progress:
            progress(i, len(items), sc["title"])
        if run_id:
            store.log(run_id, "Quality", f"Testing {i}/{len(items)}: {sc['title']}")
        t0 = time.time()
        try:
            res = run_check(sc["plan"], sc["company_type"])
        except Exception as e:
            results.append({**sc, "error": str(e)})
            continue
        flagged = [f for f in res["findings"] if f["signal"] in ("red", "yellow")]
        not_covered = [f for f in flagged if "not covered" in str(f.get("why", "")).lower()
                       or "could not point" in str(f.get("why", "")).lower()]
        cited = [f for f in flagged if f.get("sources")]
        results.append({
            "id": sc["id"], "title": sc["title"], "company_type": sc["company_type"], "topic": sc["topic"],
            "expected": sc["expected"], "got": res["overall"],
            "match": res["overall"] in sc["expected"],
            "citation_rate": round(len(cited) / len(flagged), 2) if flagged else 1.0,
            "topic_hit": sc["topic"] in res.get("evidence_topics", []),
            "covered": bool(res["findings"]) and len(not_covered) < len(flagged or [1]),
            "seconds": round(time.time() - t0, 1),
        })
    ok = [r for r in results if "error" not in r]
    summary = {
        "scenarios": len(results),
        "signal_accuracy": round(sum(r["match"] for r in ok) / len(ok), 2) if ok else 0,
        "citation_rate": round(sum(r["citation_rate"] for r in ok) / len(ok), 2) if ok else 0,
        "topic_hit_rate": round(sum(r["topic_hit"] for r in ok) / len(ok), 2) if ok else 0,
        "gaps": sorted({r["topic"] for r in ok if not r["topic_hit"]}),
        "errors": len(results) - len(ok),
    }
    store.save_eval([{"summary": summary}] + results)
    return {"summary": summary, "results": results}


if __name__ == "__main__":
    out = evaluate()
    s = out["summary"]
    print(f"\nScenarios: {s['scenarios']}   Signal accuracy: {s['signal_accuracy']:.0%}   "
          f"Citation rate: {s['citation_rate']:.0%}   Topic hit: {s['topic_hit_rate']:.0%}")
    if s["gaps"]:
        print("Topics with no matching rules loaded yet:", ", ".join(s["gaps"]))
    for r in out["results"]:
        if "error" in r:
            print(f"  {r['id']}: ERROR {r['error']}")
        else:
            mark = "OK " if r["match"] else "MISS"
            print(f"  {mark} {r['id']:4} expected {'/'.join(r['expected']):12} got {r['got']:6}  {r['title']}")
