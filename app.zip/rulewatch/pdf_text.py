"""Read text out of a PDF and cut it into small pieces (chunks) that remember their page number."""
import re
from pypdf import PdfReader


def read_pages(path: str) -> list[tuple[int, str]]:
    reader = PdfReader(path)
    pages = []
    for i, page in enumerate(reader.pages, start=1):
        try:
            text = page.extract_text() or ""
        except Exception:
            text = ""
        text = re.sub(r"[ \t]+", " ", text)
        text = re.sub(r"\n{3,}", "\n\n", text).strip()
        if text:
            pages.append((i, text))
    return pages


def read_text_sections(path: str) -> list[tuple[int, str]]:
    """For web-page rules saved as text: split at [Section N] markers. Section number acts like a page."""
    text = open(path, encoding="utf-8").read()
    parts = re.split(r"\n?\[Section (\d+)\]", text)
    sections, current = [], 1
    if parts[0].strip():
        sections.append((1, parts[0].strip()))
    for i in range(1, len(parts) - 1, 2):
        current = int(parts[i])
        body = parts[i + 1].strip()
        if body:
            sections.append((current, body))
    return sections


def read_any(path: str, kind: str) -> list[tuple[int, str]]:
    return read_text_sections(path) if kind == "html" else read_pages(path)


def chunk_pages(pages: list[tuple[int, str]], size=900, overlap=150) -> list[tuple[int, str]]:
    chunks = []
    for page_no, text in pages:
        start = 0
        while start < len(text):
            end = min(len(text), start + size)
            # try to end on a sentence or line break
            cut = max(text.rfind(". ", start, end), text.rfind("\n", start, end))
            if end < len(text) and cut > start + size // 2:
                end = cut + 1
            piece = text[start:end].strip()
            if len(piece) > 40:
                chunks.append((page_no, piece))
            if end >= len(text):
                break
            start = max(end - overlap, start + 1)
    return chunks
