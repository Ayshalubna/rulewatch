"""SQLite database: documents (rules), text chunks, companies, alerts and the agent activity log."""
import json
import re
import sqlite3
from datetime import datetime
import numpy as np

from .config import DB_PATH

SCHEMA = """
CREATE TABLE IF NOT EXISTS documents (
    id INTEGER PRIMARY KEY,
    url TEXT UNIQUE,
    title TEXT,
    regulator TEXT,
    source_page TEXT,
    sha256 TEXT,
    file_path TEXT,
    kind TEXT DEFAULT 'pdf',            -- pdf | html
    first_seen TEXT,
    last_checked TEXT,
    last_changed TEXT,
    change_type TEXT DEFAULT 'new',     -- new | updated
    status TEXT DEFAULT 'new',          -- new | read | failed
    summary_en TEXT,
    summary_ar TEXT,
    key_points TEXT,                    -- JSON list
    topics TEXT,                        -- JSON list
    affects TEXT,                       -- JSON {company_type: what_to_do}
    severity TEXT                       -- high | medium | low
);
CREATE TABLE IF NOT EXISTS chunks (
    id INTEGER PRIMARY KEY,
    doc_id INTEGER,
    page INTEGER,
    text TEXT,
    embedding BLOB
);
CREATE TABLE IF NOT EXISTS companies (
    id INTEGER PRIMARY KEY,
    name TEXT,
    type TEXT,
    activities TEXT,
    email TEXT
);
CREATE TABLE IF NOT EXISTS alerts (
    id INTEGER PRIMARY KEY,
    company_id INTEGER,
    doc_id INTEGER,
    message TEXT,
    created TEXT,
    emailed INTEGER DEFAULT 0
);
CREATE TABLE IF NOT EXISTS agent_log (
    id INTEGER PRIMARY KEY,
    ts TEXT,
    run_id TEXT,
    agent TEXT,
    message TEXT
);
CREATE TABLE IF NOT EXISTS sources (
    id INTEGER PRIMARY KEY,
    name TEXT,
    regulator TEXT,
    kind TEXT,
    url TEXT UNIQUE,
    follow TEXT,
    latest_only INTEGER DEFAULT 0,
    enabled INTEGER DEFAULT 1,
    last_status TEXT,
    last_checked TEXT
);
CREATE TABLE IF NOT EXISTS eval_runs (
    id INTEGER PRIMARY KEY,
    ts TEXT,
    results TEXT                        -- JSON
);
CREATE TABLE IF NOT EXISTS llm_cache (
    key TEXT PRIMARY KEY,
    value TEXT,
    created TEXT
);
CREATE TABLE IF NOT EXISTS page_snapshots (
    url TEXT PRIMARY KEY,
    links TEXT,
    checked_at TEXT
);
"""


def now() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def conn() -> sqlite3.Connection:
    c = sqlite3.connect(DB_PATH)
    c.row_factory = sqlite3.Row
    c.executescript(SCHEMA)
    return c


# ---------- agent log ----------
def log(run_id: str, agent: str, message: str):
    with conn() as c:
        c.execute("INSERT INTO agent_log (ts, run_id, agent, message) VALUES (?,?,?,?)",
                  (now(), run_id, agent, message))


def get_log(limit=200, run_id=None):
    with conn() as c:
        if run_id:
            rows = c.execute("SELECT * FROM agent_log WHERE run_id=? ORDER BY id", (run_id,)).fetchall()
        else:
            rows = c.execute("SELECT * FROM agent_log ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
    return [dict(r) for r in rows]


# ---------- documents ----------
def doc_exists(url: str, sha256: str | None = None) -> bool:
    with conn() as c:
        row = c.execute("SELECT sha256 FROM documents WHERE url=?", (url,)).fetchone()
    if not row:
        return False
    return sha256 is None or row["sha256"] == sha256


def get_document_by_url(url: str) -> dict | None:
    with conn() as c:
        r = c.execute("SELECT * FROM documents WHERE url=?", (url,)).fetchone()
    return _doc_row(r) if r else None


def add_document(url, title, regulator, source_page, sha256, file_path, kind="pdf") -> int:
    """Adds a new document, or marks an existing one as UPDATED when its content changed."""
    t = now()
    with conn() as c:
        old = c.execute("SELECT id, sha256 FROM documents WHERE url=?", (url,)).fetchone()
        if old and old["sha256"] == sha256:
            c.execute("UPDATE documents SET last_checked=? WHERE id=?", (t, old["id"]))
            return old["id"]
        if old:
            c.execute("""UPDATE documents SET sha256=?, file_path=?, kind=?, status='new', change_type='updated',
                         last_checked=?, last_changed=? WHERE id=?""",
                      (sha256, file_path, kind, t, t, old["id"]))
            return old["id"]
        cur = c.execute("""INSERT INTO documents (url, title, regulator, source_page, sha256, file_path, kind,
                           first_seen, last_checked, last_changed, change_type, status)
                           VALUES (?,?,?,?,?,?,?,?,?,?,'new','new')""",
                        (url, title, regulator, source_page, sha256, file_path, kind, t, t, t))
        return cur.lastrowid


def touch_document(url: str):
    with conn() as c:
        c.execute("UPDATE documents SET last_checked=? WHERE url=?", (now(), url))


def update_document(doc_id: int, **fields):
    for k in ("key_points", "topics", "affects"):
        if k in fields and not isinstance(fields[k], str):
            fields[k] = json.dumps(fields[k], ensure_ascii=False)
    sets = ", ".join(f"{k}=?" for k in fields)
    with conn() as c:
        c.execute(f"UPDATE documents SET {sets} WHERE id=?", (*fields.values(), doc_id))


def _doc_row(r) -> dict:
    d = dict(r)
    for k, default in (("key_points", []), ("topics", []), ("affects", {})):
        try:
            d[k] = json.loads(d[k]) if d.get(k) else default
        except Exception:
            d[k] = default
    return d


def get_document(doc_id: int) -> dict | None:
    with conn() as c:
        r = c.execute("SELECT * FROM documents WHERE id=?", (doc_id,)).fetchone()
    return _doc_row(r) if r else None


def list_documents(status=None) -> list[dict]:
    with conn() as c:
        if status:
            rows = c.execute("SELECT * FROM documents WHERE status=? ORDER BY id DESC", (status,)).fetchall()
        else:
            rows = c.execute("SELECT * FROM documents ORDER BY id DESC").fetchall()
    return [_doc_row(r) for r in rows]


# ---------- chunks + search ----------
def add_chunks(doc_id: int, items: list[tuple[int, str, np.ndarray]]):
    with conn() as c:
        c.execute("DELETE FROM chunks WHERE doc_id=?", (doc_id,))
        c.executemany("INSERT INTO chunks (doc_id, page, text, embedding) VALUES (?,?,?,?)",
                      [(doc_id, p, t, v.astype(np.float32).tobytes()) for p, t, v in items])


def _keyword_score(query: str, text: str) -> float:
    q = set(re.findall(r"\w{3,}", query.lower()))
    if not q:
        return 0.0
    t = set(re.findall(r"\w{3,}", text.lower()))
    return len(q & t) / len(q)


def search(query_vec: np.ndarray, query_text: str, k=6, doc_ids=None) -> list[dict]:
    """Hybrid search: meaning (vector) + exact words (keywords)."""
    with conn() as c:
        rows = c.execute("""SELECT ch.id, ch.doc_id, ch.page, ch.text, ch.embedding,
                                   d.title, d.url, d.regulator, d.kind
                            FROM chunks ch JOIN documents d ON d.id = ch.doc_id""").fetchall()
    from .embed import _hash_vec, HASH_DIM
    hash_q = None
    results = []
    for r in rows:
        if doc_ids and r["doc_id"] not in doc_ids:
            continue
        v = np.frombuffer(r["embedding"], dtype=np.float32)
        if v.shape == query_vec.shape:
            sim = float(np.dot(v, query_vec))
        elif v.shape[0] == HASH_DIM:  # piece was saved while the AI model was unavailable
            hash_q = hash_q if hash_q is not None else _hash_vec(query_text)
            sim = float(np.dot(v, hash_q))
        else:
            sim = 0.0
        score = 0.75 * sim + 0.25 * _keyword_score(query_text, r["text"])
        results.append({"chunk_id": r["id"], "doc_id": r["doc_id"], "page": r["page"], "text": r["text"],
                        "title": r["title"], "url": r["url"], "regulator": r["regulator"], "kind": r["kind"],
                        "score": score})
    results.sort(key=lambda x: x["score"], reverse=True)
    return results[:k]


def doc_topics_map() -> dict[int, list[str]]:
    with conn() as c:
        rows = c.execute("SELECT id, topics FROM documents").fetchall()
    out = {}
    for r in rows:
        try:
            out[r["id"]] = json.loads(r["topics"]) if r["topics"] else []
        except Exception:
            out[r["id"]] = []
    return out


def count_chunks() -> int:
    with conn() as c:
        return c.execute("SELECT COUNT(*) n FROM chunks").fetchone()["n"]


# ---------- companies + alerts ----------
def add_company(name, ctype, activities, email="") -> int:
    with conn() as c:
        cur = c.execute("INSERT INTO companies (name, type, activities, email) VALUES (?,?,?,?)",
                        (name, ctype, activities, email))
        return cur.lastrowid


def list_companies() -> list[dict]:
    with conn() as c:
        return [dict(r) for r in c.execute("SELECT * FROM companies ORDER BY id").fetchall()]


def delete_company(company_id: int):
    with conn() as c:
        c.execute("DELETE FROM companies WHERE id=?", (company_id,))
        c.execute("DELETE FROM alerts WHERE company_id=?", (company_id,))


def add_alert(company_id, doc_id, message) -> int:
    with conn() as c:
        cur = c.execute("INSERT INTO alerts (company_id, doc_id, message, created) VALUES (?,?,?,?)",
                        (company_id, doc_id, message, now()))
        return cur.lastrowid


def mark_emailed(alert_id: int):
    with conn() as c:
        c.execute("UPDATE alerts SET emailed=1 WHERE id=?", (alert_id,))


def list_alerts(company_id=None) -> list[dict]:
    q = """SELECT a.*, c.name company, c.type company_type, d.title doc_title, d.url doc_url, d.severity
           FROM alerts a JOIN companies c ON c.id=a.company_id JOIN documents d ON d.id=a.doc_id"""
    with conn() as c:
        if company_id:
            rows = c.execute(q + " WHERE a.company_id=? ORDER BY a.id DESC", (company_id,)).fetchall()
        else:
            rows = c.execute(q + " ORDER BY a.id DESC").fetchall()
    return [dict(r) for r in rows]


# ---------- sources ----------
def seed_sources(defaults: list[dict]):
    with conn() as c:
        for s in defaults:
            c.execute("""INSERT OR IGNORE INTO sources (name, regulator, kind, url, follow, latest_only)
                         VALUES (?,?,?,?,?,?)""",
                      (s["name"], s["regulator"], s["kind"], s["url"], s.get("follow"), int(s.get("latest_only", 0))))


def list_sources(enabled_only=False) -> list[dict]:
    with conn() as c:
        q = "SELECT * FROM sources" + (" WHERE enabled=1" if enabled_only else "") + " ORDER BY regulator, id"
        return [dict(r) for r in c.execute(q).fetchall()]


def add_source(name, regulator, kind, url, follow=None, latest_only=False):
    with conn() as c:
        c.execute("""INSERT OR IGNORE INTO sources (name, regulator, kind, url, follow, latest_only)
                     VALUES (?,?,?,?,?,?)""", (name, regulator, kind, url, follow, int(latest_only)))


def set_source_enabled(source_id: int, enabled: bool):
    with conn() as c:
        c.execute("UPDATE sources SET enabled=? WHERE id=?", (int(enabled), source_id))


def set_source_status(url: str, status: str):
    with conn() as c:
        c.execute("UPDATE sources SET last_status=?, last_checked=? WHERE url=?", (status, now(), url))


# ---------- evaluation ----------
def save_eval(results: list[dict]):
    with conn() as c:
        c.execute("INSERT INTO eval_runs (ts, results) VALUES (?,?)", (now(), json.dumps(results, ensure_ascii=False)))


def last_eval() -> dict | None:
    with conn() as c:
        r = c.execute("SELECT * FROM eval_runs ORDER BY id DESC LIMIT 1").fetchone()
    return {"ts": r["ts"], "results": json.loads(r["results"])} if r else None


def stats() -> dict:
    with conn() as c:
        docs = c.execute("SELECT regulator, status, COUNT(*) n FROM documents GROUP BY regulator, status").fetchall()
        chunks = c.execute("SELECT COUNT(*) n FROM chunks").fetchone()["n"]
        chars = c.execute("SELECT COALESCE(SUM(LENGTH(text)),0) n FROM chunks").fetchone()["n"]
    return {"docs": [dict(r) for r in docs], "chunks": chunks, "chars": chars}


# ---------- page snapshots (for the watcher) ----------
def get_snapshot(url: str) -> list[str] | None:
    with conn() as c:
        r = c.execute("SELECT links FROM page_snapshots WHERE url=?", (url,)).fetchone()
    return json.loads(r["links"]) if r else None


def save_snapshot(url: str, links: list[str]):
    with conn() as c:
        c.execute("""INSERT INTO page_snapshots (url, links, checked_at) VALUES (?,?,?)
                     ON CONFLICT(url) DO UPDATE SET links=excluded.links, checked_at=excluded.checked_at""",
                  (url, json.dumps(links), now()))


def reset_sources(defaults: list[dict]):
    """Replace the saved source list with the default one (keeps documents already read)."""
    with conn() as c:
        c.execute("DELETE FROM sources")
    seed_sources(defaults)


def cache_get(key: str):
    with conn() as c:
        r = c.execute("SELECT value FROM llm_cache WHERE key=?", (key,)).fetchone()
    return json.loads(r["value"]) if r else None


def cache_set(key: str, value: dict):
    with conn() as c:
        c.execute("INSERT OR REPLACE INTO llm_cache (key, value, created) VALUES (?,?,?)",
                  (key, json.dumps(value, ensure_ascii=False), now()))
