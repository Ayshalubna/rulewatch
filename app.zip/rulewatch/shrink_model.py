"""Build-time step for small servers (Render free plan, 512 MB).

Shrinks the multilingual search model to 8-bit numbers (about 4x less memory) and checks that the
shrunk model still gives the same search vectors as the full one (and as the vectors saved in the
database). The app then uses it with plain onnxruntime when EMBED_ONNX is set.

    python -m rulewatch.shrink_model /app/models
"""
import glob
import os
import shutil
import sqlite3
import sys

import numpy as np

MODEL_NAME = "sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2"


def main(cache: str):
    from fastembed import TextEmbedding
    full = TextEmbedding(MODEL_NAME, cache_dir=cache)
    onnx = [p for p in glob.glob(os.path.join(cache, "**", "*.onnx"), recursive=True) if "small" not in p][0]
    folder = os.path.dirname(onnx)
    tok = glob.glob(os.path.join(cache, "**", "tokenizer.json"), recursive=True)[0]
    out_dir = os.path.join(cache, "small")
    os.makedirs(out_dir, exist_ok=True)
    out = os.path.join(out_dir, "model_int8.onnx")
    print(f"full model: {onnx} ({os.path.getsize(onnx) // 2**20} MB)")

    from onnxruntime.quantization import QuantType, quantize_dynamic
    quantize_dynamic(onnx, out, weight_type=QuantType.QInt8,
                     op_types_to_quantize=["MatMul", "Gather", "Attention"])
    shutil.copy(tok, os.path.join(out_dir, "tokenizer.json"))
    print(f"small model: {out} ({os.path.getsize(out) // 2**20} MB)")

    # --- check quality: compare small vs full on sample texts and on saved database vectors
    os.environ["EMBED_ONNX"] = out
    from rulewatch import embed as E
    samples = ["Buyer payments for off-plan units must go into the escrow account.",
               "Can a landlord raise the rent by 25%?", "رخصة الإعلان العقاري ورمز الاستجابة السريعة",
               "Selling tokens of a villa without a VARA licence", "holiday home permit DTCM"]
    a = [np.asarray(v, dtype=np.float32) for v in full.embed(samples)]
    a = [v / np.linalg.norm(v) for v in a]
    b = E.embed(samples)
    cos = [float(np.dot(x, y)) for x, y in zip(a, b)]
    print("small vs full model, similarity per sample:", [round(c, 3) for c in cos])

    db = os.path.join(os.getcwd(), "data", "rulewatch.db")
    if os.path.exists(db):
        c = sqlite3.connect(db)
        rows = c.execute("SELECT text, embedding FROM chunks ORDER BY id LIMIT 40").fetchall()
        saved = [np.frombuffer(r[1], dtype=np.float32) for r in rows]
        new = E.embed([r[0] for r in rows])
        sims = [float(np.dot(s, n)) for s, n in zip(saved, new) if s.shape == n.shape]
        print(f"small model vs saved database vectors: mean {np.mean(sims):.3f}, min {np.min(sims):.3f} "
              f"({len(sims)} passages)")
    if min(cos) < 0.9:
        sys.exit("Shrunk model is too different from the full one. Stopping the build.")
    # remove the full model files to keep the image small
    shutil.rmtree(folder, ignore_errors=True)
    print("OK: small search model ready.")


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else "/app/models")
