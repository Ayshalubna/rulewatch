"""All settings in one place."""
import os
from pathlib import Path
from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parent.parent
load_dotenv(ROOT / ".env")

DATA_DIR = ROOT / "data"
PDF_DIR = DATA_DIR / "pdfs"
DB_PATH = DATA_DIR / "rulewatch.db"
DATA_DIR.mkdir(exist_ok=True)
PDF_DIR.mkdir(exist_ok=True)

LLM_PROVIDER = os.getenv("LLM_PROVIDER", "mock").lower()
LLM_API_KEY = os.getenv("LLM_API_KEY", "")
LLM_BASE_URL = os.getenv("LLM_BASE_URL", "https://api.groq.com/openai/v1")
LLM_MODEL = os.getenv("LLM_MODEL", "openai/gpt-oss-120b")
# Smaller, faster model used for the heavy "read every section" work (saves free-tier limits)
LLM_FAST_MODEL = os.getenv("LLM_FAST_MODEL", "openai/gpt-oss-20b")
# If a model hits its daily limit or is unavailable, RuleWatch automatically moves to the next one
LLM_FALLBACK_MODELS = [m.strip() for m in os.getenv(
    "LLM_FALLBACK_MODELS",
    "qwen/qwen3.8-27b,openai/gpt-oss-20b,openai/gpt-oss-120b").split(",")
    if m.strip()]

# How deep the Reader goes into long documents (each section = ~7,000 characters)
MAX_SECTIONS_PER_DOC = int(os.getenv("MAX_SECTIONS_PER_DOC", "8"))
# Re-check already-known documents for new versions after this many days
RECHECK_DAYS = int(os.getenv("RECHECK_DAYS", "7"))

RESEND_API_KEY = os.getenv("RESEND_API_KEY", "")
ALERT_FROM_EMAIL = os.getenv("ALERT_FROM_EMAIL", "onboarding@resend.dev")

USER_AGENT = "RuleWatch/1.0 (compliance research prototype; checks public pages once a day)"

# ---------------------------------------------------------------------------
# OFFICIAL SOURCES the Watcher checks. These are the starting list; you can add more
# from the Watcher tab in the app (they are saved in the database).
#
# kind:
#   listing   = a page with many document links (PDF / HTML). New links = new rules.
#   crawl     = start page; follow links matching `follow` one level deep and collect
#               documents there. `latest_only` keeps only the newest version of each file.
#   document  = one fixed official document (PDF or web page). Re-checked for changes.
# ---------------------------------------------------------------------------
DLP = "https://dlp.dubai.gov.ae/Legislation%20Reference/"

DEFAULT_SOURCES = [
    # ---- Dubai laws (official text, Dubai Legislation Portal) ----
    {"name": "Law No. 8 of 2007 – Escrow accounts for real estate development", "regulator": "Dubai Legislation",
     "kind": "document", "url": DLP + "2007/Law%20No.%20(8)%20of%202007%20Concerning%20Escrow%20Accounts%20for%20Real%20Estate%20Development%20in%20the%20Emirate%20of%20Dubai.html"},
    {"name": "Law No. 13 of 2008 – Interim real estate register (off-plan)", "regulator": "Dubai Legislation",
     "kind": "document", "url": DLP + "2008/Law%20No.%20(13)%20of%202008%20Initial%20real%20estate%20registration.html"},
    {"name": "Law No. 26 of 2007 – Landlords and tenants", "regulator": "Dubai Legislation",
     "kind": "document", "url": DLP + "2007/Law%20No.%20(26)%20of%202007%20Regarding%20regulation%20between%20the%20lessor%20and%20the%20lessee.html"},
    {"name": "Law No. 33 of 2008 – Amending the tenancy law", "regulator": "Dubai Legislation",
     "kind": "document", "url": DLP + "2009/Law%20No.%20(33)%20of%202008%20Amending%20Law%20No.%20(26)%20of%202007.html"},
    {"name": "Decree No. 43 of 2013 – Rent increase", "regulator": "Dubai Legislation", "kind": "document",
     "url": DLP + "2013/Decree%20No.%20%2843%29%20of%202013%20Determining%20Rent%20Increase%20for%20Real%20Property.html"},
    {"name": "Law No. 6 of 2019 – Jointly owned property", "regulator": "Dubai Legislation", "kind": "document",
     "url": DLP + "2019/Law%20No.%20(6)%20of%202019%20Concerning%20Ownership%20of%20Jointly%20Owned%20Real%20Property%20in%20the%20Emirate%20of%20Dubai.html"},
    {"name": "Decree No. 41 of 2013 – Holiday homes", "regulator": "Dubai Legislation", "kind": "document",
     "url": DLP + "2013/Decree%20No.%20(41)%20of%202013.html"},
    {"name": "Executive Council Resolution No. 6 of 2010 – Off-plan sales bylaw", "regulator": "Dubai Legislation",
     "kind": "document", "url": DLP + "2010/Executive%20Council%20Resolution%20No.%20%286%29%20of%202010%20Approving%20the%20Implementing%20Bylaw%20of%20Law%20No.%20%2813%29%20of%202008.html"},
    {"name": "Administrative Resolution No. 1 of 2020 – Holiday homes", "regulator": "Dubai Legislation",
     "kind": "document", "url": DLP + "2020/Administrative%20Resolution%20No.%20(1)%20of%202020.html"},

    # ---- DLD / RERA ----
    {"name": "RERA real estate advertisements – terms and conditions (Arabic)", "regulator": "DLD/RERA", "kind": "document",
     "url": "https://dubailand.gov.ae/media/daylptgk/الشروط-والاحكام-الخاصة-بالإعلانات-العقارية-1.pdf"},
    {"name": "RERA circular – real estate ads and promotional campaigns (Arabic)", "regulator": "DLD/RERA", "kind": "document",
     "url": "https://dubailand.gov.ae/media/fsefy3hz/الاعلانات-العقارية-والحملات-الترويجية.pdf"},
    {"name": "RERA circular – QR code required on real estate ads (Arabic)", "regulator": "DLD/RERA", "kind": "document",
     "url": "https://dubailand.gov.ae/media/bxvawlef/تطبيق-نظام-رمز-القارئ-السريع-_-qr-code-بالنسبة-للإعلانات-العقارية.pdf"},
    {"name": "DLD Real Estate Brokerage Practice Guide 2024", "regulator": "DLD/RERA", "kind": "document",
     "url": "https://dubailand.gov.ae/media/i31iv1n0/real_estate_brokerage_practice_guide_2024.pdf"},
    {"name": "Decree on rent increase in Dubai (DLD copy)", "regulator": "DLD/RERA", "kind": "document",
     "url": "https://dubailand.gov.ae/media/z2dn3gtr/rental-increase-decree-43-in-dubai.pdf"},
    {"name": "DLD Real Estate Legislation book", "regulator": "DLD/RERA", "kind": "document",
     "url": "https://rdc.dubailand.gov.ae/Assets/img/Real_Estate_Legislation_en.pdf"},
    {"name": "DLD legislation (English)", "regulator": "DLD/RERA", "kind": "document",
     "url": "https://dubailand.gov.ae/media/1omljeok/legislation_en.pdf"},
    {"name": "DLD / RERA documents & circulars", "regulator": "DLD/RERA", "kind": "listing",
     "url": "https://dubailand.gov.ae/en/about-dubai-land-department/survey-guide"},

    # ---- VARA (virtual assets & property tokenization) ----
    {"name": "VARA Law No. 4 of 2022 – Regulating virtual assets in Dubai", "regulator": "VARA", "kind": "document",
     "url": "https://rulebooks.vara.ae/sites/default/files/en_net_file_store/VARA_EN_338_VER1.pdf"},
    {"name": "VARA Virtual Asset Issuance Rulebook (covers property tokens)", "regulator": "VARA", "kind": "document",
     "url": "https://rulebooks.vara.ae/sites/default/files/en_net_file_store/VARA_EN_293_VER20250619.pdf"},
    {"name": "VARA rulebooks that matter for real estate", "regulator": "VARA", "kind": "crawl",
     "url": "https://rulebooks.vara.ae/rulebook/rulebooks",
     "follow": r"rulebook/(virtual-asset-issuance|market-conduct|compliance-and-risk-management|company)-rulebook$",
     "latest_only": True},
    {"name": "VARA – changed in the last 30 days", "regulator": "VARA", "kind": "crawl",
     "url": "https://rulebooks.vara.ae/view-revision-updates?f_days=on&changed=-30%20day",
     "follow": r"rulebook/(virtual-asset-issuance|market-conduct|compliance-and-risk-management|company)-rulebook$",
     "latest_only": True},
]

# ---------------------------------------------------------------------------
# WHO uses RuleWatch. Each type cares about different topics.
# ---------------------------------------------------------------------------
COMPANY_TYPES = {
    "Real estate agency / broker": ["advertising & marketing", "brokerage licensing", "leasing & tenancy",
                                     "AML / KYC", "off-plan & escrow", "data & consumer protection"],
    "Developer": ["off-plan & escrow", "advertising & marketing", "jointly owned property & service charges",
                  "registration & title deeds", "AML / KYC"],
    "Property manager": ["leasing & tenancy", "rent increase", "jointly owned property & service charges",
                         "disputes & enforcement", "holiday homes"],
    "Individual landlord": ["leasing & tenancy", "rent increase", "holiday homes", "disputes & enforcement"],
    "Holiday homes / short-term rental operator": ["holiday homes", "leasing & tenancy", "advertising & marketing",
                                                   "data & consumer protection"],
    "Owners association / community manager": ["jointly owned property & service charges", "disputes & enforcement"],
    "Tokenization / PropTech startup": ["tokenization & virtual assets", "AML / KYC", "advertising & marketing",
                                        "data & consumer protection", "registration & title deeds"],
    "Mortgage broker / bank": ["mortgage & finance", "AML / KYC", "valuation", "registration & title deeds"],
    "Valuation firm": ["valuation", "AML / KYC", "registration & title deeds"],
    "Facility management / maintenance company": ["jointly owned property & service charges",
                                                  "leasing & tenancy", "data & consumer protection"],
    "Tenant or buyer (individual)": ["leasing & tenancy", "rent increase", "off-plan & escrow",
                                     "disputes & enforcement", "registration & title deeds"],
}

TOPICS = sorted({t for topics in COMPANY_TYPES.values() for t in topics} | {"other"})

# Simple keyword hints so the app can tag documents even before the AI reads them
TOPIC_HINTS = {
    "advertising & marketing": ["advert", "marketing", "promot", "trakheesi", "portal", "permit for ad", "qr code"],
    "brokerage licensing": ["broker", "brokerage", "licen", "simsari", "real estate agent"],
    "leasing & tenancy": ["lease", "tenant", "tenancy", "landlord", "ejari", "rent"],
    "rent increase": ["rent increase", "rental index", "increase in rent", "decree no. (43)", "decree 43"],
    "off-plan & escrow": ["escrow", "off-plan", "off plan", "interim", "oqood", "project account"],
    "jointly owned property & service charges": ["jointly owned", "owners association", "service charge",
                                                 "service fee", "mollak", "strata", "common areas"],
    "holiday homes": ["holiday home", "short-term", "short term", "vacation rental"],
    "tokenization & virtual assets": ["virtual asset", "token", "vara", "whitepaper", "issuance"],
    "AML / KYC": ["money laundering", "aml", "kyc", "know your customer", "due diligence", "goaml",
                  "terrorism financing", "suspicious"],
    "valuation": ["valuation", "valuer", "taqyeem"],
    "mortgage & finance": ["mortgage", "financ", "loan", "lender"],
    "registration & title deeds": ["title deed", "registration", "register", "transfer of ownership"],
    "disputes & enforcement": ["dispute", "penalt", "fine", "violation", "eviction", "rental disputes"],
    "data & consumer protection": ["personal data", "consumer", "privacy", "complaint", "disclosure"],
}
