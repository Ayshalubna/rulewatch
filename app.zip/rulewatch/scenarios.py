"""Real-life business situations used for demos and for the quality test.

`expected` = the signal(s) a compliance officer would expect, based on well-known Dubai rules.
They are used to measure how good RuleWatch is. They are not legal advice.
"""

SCENARIOS = [
    # ---------------- Real estate agency / broker ----------------
    {"id": "AG1", "company_type": "Real estate agency / broker", "topic": "advertising & marketing",
     "title": "Instagram ad without a permit",
     "plan": "Tomorrow we will post a paid Instagram and TikTok ad for a 2-bed apartment in Dubai Marina. "
             "We have not applied for an advertising permit; we will do it after the ad gets leads.",
     "expected": ["red"]},
    {"id": "AG2", "company_type": "Real estate agency / broker", "topic": "advertising & marketing",
     "title": "Ad promising guaranteed returns",
     "plan": "Our new campaign headline will be 'Guaranteed 10% rental return for 5 years' for units in JVC, "
             "without naming who gives the guarantee.",
     "expected": ["red", "yellow"]},
    {"id": "AG3", "company_type": "Real estate agency / broker", "topic": "brokerage licensing",
     "title": "New agent working before getting a broker card",
     "plan": "We hired a new sales agent last week. She will show villas to clients and sign viewing "
             "agreements this weekend while her broker registration and card are still being processed.",
     "expected": ["red", "yellow"]},
    {"id": "AG4", "company_type": "Real estate agency / broker", "topic": "off-plan & escrow",
     "title": "Marketing an unregistered off-plan project",
     "plan": "A developer friend gave us an off-plan tower that is not yet registered with the Land Department "
             "and has no escrow account yet. We will start marketing it and taking reservations now.",
     "expected": ["red"]},
    {"id": "AG5", "company_type": "Real estate agency / broker", "topic": "AML / KYC",
     "title": "Big cash buyer, no ID checks",
     "plan": "A foreign buyer wants to pay AED 2.5 million in cash for a villa. To close fast we will skip "
             "the identity checks and source-of-funds questions.",
     "expected": ["red"]},
    {"id": "AG6", "company_type": "Real estate agency / broker", "topic": "leasing & tenancy",
     "title": "Using the standard lease brokerage forms",
     "plan": "For every rental we will use the official lease brokerage agreement between owner and broker, "
             "and the agreement between broker and tenant.",
     "expected": ["green", "yellow"]},

    # ---------------- Developer ----------------
    {"id": "DV1", "company_type": "Developer", "topic": "off-plan & escrow",
     "title": "Buyer payments into company account",
     "plan": "We start selling our new tower next month. Buyers will pay the 20% down payment into our normal "
             "company bank account while the escrow account is being opened.",
     "expected": ["red"]},
    {"id": "DV2", "company_type": "Developer", "topic": "advertising & marketing",
     "title": "Launch event before registration",
     "plan": "We will run a big launch event and billboards for our project before the project is registered "
             "and before we have marketing approvals.",
     "expected": ["red", "yellow"]},
    {"id": "DV3", "company_type": "Developer", "topic": "jointly owned property & service charges",
     "title": "Setting service charges ourselves",
     "plan": "After handover we will set and collect service charges for the building at our own rate, "
             "without submitting a budget for approval.",
     "expected": ["red", "yellow"]},

    # ---------------- Property manager / landlord ----------------
    {"id": "PM1", "company_type": "Property manager", "topic": "rent increase",
     "title": "20% rent increase on renewal",
     "plan": "On renewal we will increase all tenants' rent by 20% in one building, even where current rent "
             "is already close to the market average in the rental index.",
     "expected": ["red"]},
    {"id": "LL1", "company_type": "Individual landlord", "topic": "leasing & tenancy",
     "title": "Eviction by WhatsApp with 30 days notice",
     "plan": "I want to move into my apartment, so I will send my tenant a WhatsApp message giving 30 days "
             "to leave.",
     "expected": ["red"]},
    {"id": "LL2", "company_type": "Individual landlord", "topic": "leasing & tenancy",
     "title": "Lease not registered",
     "plan": "I will rent my flat with a simple paper contract and will not register it in Ejari to save time.",
     "expected": ["red", "yellow"]},
    {"id": "LL3", "company_type": "Individual landlord", "topic": "rent increase",
     "title": "Rent increase following the index with notice",
     "plan": "I will check the official rental index and send my tenant the allowed increase 90 days before "
             "the contract ends.",
     "expected": ["green", "yellow"]},

    # ---------------- Holiday homes ----------------
    {"id": "HH1", "company_type": "Holiday homes / short-term rental operator", "topic": "holiday homes",
     "title": "Airbnb listing without a holiday home permit",
     "plan": "We will list 15 apartments in Downtown on Airbnb and Booking.com for nightly stays starting "
             "next week. We have no holiday home permit yet.",
     "expected": ["red"]},

    # ---------------- Owners association ----------------
    {"id": "OA1", "company_type": "Owners association / community manager",
     "topic": "jointly owned property & service charges",
     "title": "Blocking access for unpaid service fees",
     "plan": "Owners who have not paid service charges will have their access cards blocked so they cannot "
             "use their own apartments until they pay.",
     "expected": ["red", "yellow"]},
    {"id": "OA2", "company_type": "Owners association / community manager",
     "topic": "jointly owned property & service charges",
     "title": "Collecting fees without an approved budget",
     "plan": "This year we will collect higher service fees from owners. The new budget has not been "
             "approved by the regulator yet.",
     "expected": ["red", "yellow"]},

    # ---------------- Tokenization ----------------
    {"id": "TK1", "company_type": "Tokenization / PropTech startup", "topic": "tokenization & virtual assets",
     "title": "Selling property tokens without a licence",
     "plan": "We will sell digital tokens representing shares of a Dubai Marina apartment to the public from "
             "AED 1,000 each. We have not applied for any VARA licence.",
     "expected": ["red"]},
    {"id": "TK2", "company_type": "Tokenization / PropTech startup", "topic": "AML / KYC",
     "title": "Token buyers without ID checks",
     "plan": "To grow fast, buyers can purchase our property tokens with only an email address. No ID or "
             "source-of-funds checks.",
     "expected": ["red"]},
    {"id": "TK3", "company_type": "Tokenization / PropTech startup", "topic": "tokenization & virtual assets",
     "title": "Whitepaper with clear risk disclosure",
     "plan": "Before our licensed token issuance we will publish a whitepaper explaining the property, how "
             "rental income is shared with token holders, and the risks.",
     "expected": ["green", "yellow"]},
    {"id": "TK4", "company_type": "Tokenization / PropTech startup", "topic": "tokenization & virtual assets",
     "title": "Token marketing promising profit",
     "plan": "Our social media ads will say 'Buy property tokens, guaranteed 12% yearly profit, zero risk'.",
     "expected": ["red", "yellow"]},

    # ---------------- Mortgage / bank / valuation ----------------
    {"id": "MB1", "company_type": "Mortgage broker / bank", "topic": "AML / KYC",
     "title": "Funds from an unknown third party",
     "plan": "A buyer's down payment will come from a company abroad we don't know. We will accept it "
             "without asking who owns the company.",
     "expected": ["red", "yellow"]},
    {"id": "VF1", "company_type": "Valuation firm", "topic": "valuation",
     "title": "Valuation by an unregistered valuer",
     "plan": "To handle more mortgage valuations, our junior staff who are not registered valuers will sign "
             "valuation reports.",
     "expected": ["red", "yellow"]},

    # ---------------- Facility management ----------------
    {"id": "FM1", "company_type": "Facility management / maintenance company",
     "topic": "data & consumer protection",
     "title": "Sharing residents' data with marketers",
     "plan": "We will share residents' names, phone numbers and flat numbers with a marketing partner "
             "without asking residents.",
     "expected": ["red", "yellow"]},

    # ---------------- Individuals ----------------
    {"id": "TN1", "company_type": "Tenant or buyer (individual)", "topic": "rent increase",
     "title": "Tenant pays only the allowed increase",
     "plan": "My landlord asked for a 15% increase. I will check the rental index and agree only to the "
             "increase the rules allow.",
     "expected": ["green", "yellow"]},
    {"id": "TN2", "company_type": "Tenant or buyer (individual)", "topic": "off-plan & escrow",
     "title": "Off-plan buyer paying the developer directly",
     "plan": "I am buying an off-plan flat. The sales agent asked me to transfer my payment to the developer's "
             "general company account, not an escrow account. I will do it.",
     "expected": ["red", "yellow"]},
    {"id": "TN3", "company_type": "Tenant or buyer (individual)", "topic": "registration & title deeds",
     "title": "Buying without checking the title deed",
     "plan": "I will buy a ready apartment from a private seller and pay him directly without checking the "
             "title deed or registering the transfer with the Land Department.",
     "expected": ["red", "yellow"]},
]
