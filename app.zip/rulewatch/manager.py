"""MANAGER: connects the agents into two workflows using LangGraph.

1) Watch workflow (runs every day by itself):
   Watcher → Reader → Impact → Alert

2) Plan check workflow (when a company asks "is my plan OK?"):
   Planner → Retriever → Checker → Verifier → Reporter
"""
import uuid
from typing import TypedDict

from langgraph.graph import StateGraph, START, END

from . import config, store
from .agents import watcher, reader, impact, alerter, checker


def new_run_id() -> str:
    return uuid.uuid4().hex[:8]


# =============== 1) WATCH WORKFLOW ===============
class WatchState(TypedDict, total=False):
    run_id: str
    max_new: int
    pending_ids: list[int]   # documents waiting to be read (new downloads + uploaded PDFs)
    read_ids: list[int]
    alerts_sent: int


def _watch(state: WatchState) -> WatchState:
    ids = list(state.get("pending_ids", []))
    store.seed_sources(config.DEFAULT_SOURCES)
    budget = [state.get("max_new", 5)]
    for src in store.list_sources(enabled_only=True):
        ids += watcher.check_source(src, state["run_id"], budget)
    ids += [d["id"] for d in store.list_documents(status="new") if d["id"] not in ids]
    store.log(state["run_id"], "Manager", f"{len(ids)} document(s) to process")
    return {"pending_ids": ids}


def _read(state: WatchState) -> WatchState:
    ok = []
    for i in state["pending_ids"]:
        try:
            if reader.read_document(i, state["run_id"]):
                ok.append(i)
        except Exception as e:
            store.log(state["run_id"], "Reader", f"Skipped one document: {str(e)[:150]}")
    # documents that were read before but never got an impact check (e.g. an earlier run stopped)
    ok += [d["id"] for d in store.list_documents(status="read") if not d.get("severity") and d["id"] not in ok]
    return {"read_ids": ok}


def _impact(state: WatchState) -> WatchState:
    for i in state["read_ids"]:
        try:
            impact.assess(i, state["run_id"])
        except Exception as e:
            store.log(state["run_id"], "Impact", f"Could not assess one document yet: {str(e)[:150]}")
    return {}


def _alert(state: WatchState) -> WatchState:
    sent = 0
    for i in state["read_ids"]:
        try:
            sent += alerter.notify(i, state["run_id"])
        except Exception as e:
            store.log(state["run_id"], "Alert", f"Could not send one alert: {str(e)[:150]}")
    store.log(state["run_id"], "Manager", f"Done. {len(state['read_ids'])} new rule(s) processed, {sent} alert(s) sent")
    return {"alerts_sent": sent}


def _route_after_watch(state: WatchState) -> str:
    unassessed = [d for d in store.list_documents(status="read") if not d.get("severity")]
    if state["pending_ids"] or unassessed:
        return "read"
    store.log(state["run_id"], "Manager", "No new rules today. Nothing to do.")
    return END


def _route_after_read(state: WatchState) -> str:
    return "impact" if state["read_ids"] else END


def build_watch_graph(skip_web=False):
    g = StateGraph(WatchState)
    if skip_web:
        g.add_node("watch", lambda s: {"pending_ids": [d["id"] for d in store.list_documents(status="new")]})
    else:
        g.add_node("watch", _watch)
    g.add_node("read", _read)
    g.add_node("impact", _impact)
    g.add_node("alert", _alert)
    g.add_edge(START, "watch")
    g.add_conditional_edges("watch", _route_after_watch, ["read", END])
    g.add_conditional_edges("read", _route_after_read, ["impact", END])
    g.add_edge("impact", "alert")
    g.add_edge("alert", END)
    return g.compile()


def run_watch(max_new=5, skip_web=False, run_id=None) -> dict:
    """skip_web=True only processes PDFs you uploaded (no website check)."""
    run_id = run_id or new_run_id()
    store.log(run_id, "Manager", "Starting daily rule check" if not skip_web else "Processing uploaded PDFs")
    result = build_watch_graph(skip_web).invoke({"run_id": run_id, "max_new": max_new, "pending_ids": []})
    return {"run_id": run_id, **result}


# =============== 2) PLAN CHECK WORKFLOW ===============
class CheckState(TypedDict, total=False):
    run_id: str
    company_type: str
    activities: str
    plan: str
    language: str
    actions: list[str]
    queries: list[str]
    topics: list[str]
    evidence: list[dict]
    findings: list[dict]
    result: dict


BUSY = ("The AI checker is busy right now (free plan limit), so this action was not judged automatically. "
        "The official rules RuleWatch found for it are shown below. Please read them, or try again in a minute.")


def _plan(s: CheckState) -> CheckState:
    try:
        out = checker.plan_analyzer(s["plan"], s["company_type"], s["run_id"])
    except Exception as e:
        store.log(s["run_id"], "Planner", f"AI busy, checking the plan as one action ({str(e)[:80]})")
        out = {"actions": [s["plan"][:300]], "queries": [s["plan"]], "topics": []}
    topics = [t for t in out.get("topics", []) if t in config.TOPICS]
    return {"actions": out.get("actions") or [s["plan"]], "queries": out.get("queries") or [s["plan"]],
            "topics": topics}


def _plan_topics(plan: str) -> list[str]:
    """Topics the plan text clearly talks about (simple keyword match, works even if the AI is busy)."""
    p = plan.lower()
    extra = {"off-plan & escrow": ["bank account", "buyer payment", "instalment", "installment", "deposit"],
             "advertising & marketing": ["instagram", "facebook", "tiktok", "ads", "ad ", "billboard", "campaign"],
             "tokenization & virtual assets": ["crypto", "blockchain", "fractional"]}
    return [t for t, hints in config.TOPIC_HINTS.items()
            if any(h in p for h in hints + extra.get(t, []))]


def _retrieve(s: CheckState) -> CheckState:
    spotted = _plan_topics(s["plan"])
    focus = list(dict.fromkeys(spotted + s.get("topics", []) + config.COMPANY_TYPES.get(s["company_type"], [])))
    # one direct search per topic the plan mentions, so each topic gets its own law
    topic_qs = [f"{t} rules: " + ", ".join(config.TOPIC_HINTS[t][:5]) for t in spotted]
    queries = list(dict.fromkeys(topic_qs + (s.get("actions") or []) + (s.get("queries") or [])))[:10] or [s["plan"]]
    return {"evidence": checker.retrieve(queries, s["run_id"], limit=12, focus_topics=focus,
                                         strong_topics=spotted)}


def _check(s: CheckState) -> CheckState:
    try:
        return {"findings": checker.check(s["plan"], s["company_type"], s.get("activities", ""),
                                          s["actions"], s["evidence"], s["run_id"])}
    except Exception as e:
        store.log(s["run_id"], "Checker", f"AI busy, showing the rules found instead ({str(e)[:80]})")
        top = [e["eid"] for e in s["evidence"][:2]]
        return {"findings": [{"action": a, "signal": "yellow", "why": BUSY, "evidence": top,
                              "what_to_do": "Review the official passages below before going ahead.",
                              "ai_busy": True} for a in s["actions"]]}


def _verify(s: CheckState) -> CheckState:
    return {"findings": checker.verify(s["findings"], s["evidence"], s["run_id"])}


def _report(s: CheckState) -> CheckState:
    if not s.get("evidence"):
        return {"findings": [], "result": {"overall": "yellow", "counts": {"green": 0, "yellow": 0, "red": 0},
                                           "summary": "No rules are loaded yet. Run the Watcher or upload rule PDFs first."}}
    try:
        return {"result": checker.report(s["findings"], s.get("language", "en"), s["run_id"])}
    except Exception:
        order = {"green": 0, "yellow": 1, "red": 2}
        overall = max((f["signal"] for f in s["findings"]), key=lambda x: order[x], default="yellow")
        counts = {k: sum(f["signal"] == k for f in s["findings"]) for k in order}
        store.log(s["run_id"], "Reporter", f"Overall signal: {overall.upper()}")
        return {"result": {"overall": overall, "counts": counts,
                           "summary": f"{counts['red']} action(s) look against the rules, {counts['yellow']} need a "
                                      f"careful check and {counts['green']} look fine. See each action below."}}


def _route_after_retrieve(s: CheckState) -> str:
    return "check" if s.get("evidence") else "report"


def build_check_graph():
    g = StateGraph(CheckState)
    g.add_node("plan", _plan)
    g.add_node("retrieve", _retrieve)
    g.add_node("check", _check)
    g.add_node("verify", _verify)
    g.add_node("report", _report)
    g.add_edge(START, "plan")
    g.add_edge("plan", "retrieve")
    g.add_conditional_edges("retrieve", _route_after_retrieve, ["check", "report"])
    g.add_edge("check", "verify")
    g.add_edge("verify", "report")
    g.add_edge("report", END)
    return g.compile()


def run_check(plan: str, company_type: str, activities="", language="en", run_id=None) -> dict:
    run_id = run_id or new_run_id()
    store.log(run_id, "Manager", f"Checking a plan for a {company_type}")
    out = build_check_graph().invoke({"run_id": run_id, "plan": plan, "company_type": company_type,
                                      "activities": activities, "language": language})
    ev_topics = sorted({t for e in out.get("evidence", []) for t in e.get("topics", [])})
    return {"run_id": run_id, "findings": out.get("findings", []), "evidence_topics": ev_topics,
            "evidence_count": len(out.get("evidence", [])), **out["result"]}


def run_ask(question: str, language="en", run_id=None) -> dict:
    run_id = run_id or new_run_id()
    store.log(run_id, "Manager", "Answering a question about the rules")
    try:
        return {"run_id": run_id, **checker.ask(question, language, run_id)}
    except Exception as e:
        store.log(run_id, "Manager", f"AI busy, showing the most relevant rules instead ({str(e)[:80]})")
        ev = checker.retrieve([question], run_id, per_query=3, limit=3)
        msg = ("The AI is busy right now (free plan limit). These are the official passages that best match your "
               "question. Try again in a minute for a written answer.")
        if language == "ar":
            msg = "الذكاء الاصطناعي مشغول الآن. هذه أقرب المقاطع الرسمية لسؤالك. حاول مرة أخرى بعد دقيقة."
        return {"run_id": run_id, "answer": msg, "ai_busy": True,
                "sources": [{"eid": e["eid"], "title": e["title"], "page": e["page"], "url": e["url"],
                             "regulator": e["regulator"], "kind": e.get("kind"), "quote": e["text"][:350]} for e in ev]}
