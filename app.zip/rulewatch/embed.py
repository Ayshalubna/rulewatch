"""Turns text into vectors so we can search rules by meaning (works for English and Arabic).

Uses a small multilingual model (about 220 MB, downloaded once on first run).
If the model can't load (no internet), it falls back to a simple keyword-hash vector
so the app still works.
"""
import hashlib
import os
import re
import numpy as np

MODEL_NAME = "sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2"
_model = None
_mode = None  # "model" or "hash"
HASH_DIM = 512


def _load():
    global _model, _mode
    if _mode:
        return
    if os.getenv("EMBED_MODE", "").lower() == "hash":  # force the simple mode (tests / no internet)
        _mode = "hash"
        return
    try:
        from fastembed import TextEmbedding
        cache = os.getenv("FASTEMBED_CACHE") or None
        threads = int(os.getenv("EMBED_THREADS", "0")) or None   # 1 on small servers to save memory
        _model = TextEmbedding(MODEL_NAME, cache_dir=cache, threads=threads)
        _mode = "model"
    except Exception:
        _mode = "hash"


def _hash_vec(text: str) -> np.ndarray:
    v = np.zeros(HASH_DIM, dtype=np.float32)
    for w in re.findall(r"\w+", text.lower()):
        h = int(hashlib.md5(w.encode()).hexdigest(), 16)
        v[h % HASH_DIM] += 1.0
    n = np.linalg.norm(v)
    return v / n if n else v


def embed(texts: list[str]) -> list[np.ndarray]:
    _load()
    if _mode == "model":
        out = []
        for v in _model.embed(texts):
            v = np.asarray(v, dtype=np.float32)
            out.append(v / (np.linalg.norm(v) or 1.0))
        return out
    return [_hash_vec(t) for t in texts]


def mode() -> str:
    _load()
    return _mode
