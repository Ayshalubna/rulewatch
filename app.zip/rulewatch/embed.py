"""Turns text into vectors so we can search rules by meaning (works for English and Arabic).

Uses a small multilingual model (about 220 MB, downloaded once on first run).
If the model can't load (no internet), it falls back to a simple keyword-hash vector
so the app still works.
"""
import hashlib
import os
import re
import numpy as np

MODEL_NAME = "sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2"
_model = None
_mode = None  # "model" or "hash"
HASH_DIM = 512


def _load():
    global _model, _mode
    if _mode:
        return
    if os.getenv("EMBED_MODE", "").lower() == "hash":  # force the simple mode (tests / no internet)
        _mode = "hash"
        return
    small = os.getenv("EMBED_ONNX")
    if small and os.path.exists(small):  # shrunk 8-bit model for small servers (see shrink_model.py)
        try:
            _model = _SmallModel(small)
            _mode = "small"
            return
        except Exception:
            pass
    try:
        from fastembed import TextEmbedding
        cache = os.getenv("FASTEMBED_CACHE") or None
        threads = int(os.getenv("EMBED_THREADS", "0")) or None   # 1 on small servers to save memory
        _model = TextEmbedding(MODEL_NAME, cache_dir=cache, threads=threads)
        _mode = "model"
    except Exception:
        _mode = "hash"


class _SmallModel:
    """Same model as fastembed (mean pooling), run directly with onnxruntime using little memory."""
    def __init__(self, path):
        import onnxruntime as ort
        from tokenizers import Tokenizer
        so = ort.SessionOptions()
        so.enable_cpu_mem_arena = False
        so.intra_op_num_threads = 1
        so.inter_op_num_threads = 1
        self.sess = ort.InferenceSession(path, so, providers=["CPUExecutionProvider"])
        self.inputs = {i.name for i in self.sess.get_inputs()}
        self.tok = Tokenizer.from_file(os.path.join(os.path.dirname(path), "tokenizer.json"))
        self.tok.enable_truncation(max_length=128)

    def embed(self, texts):
        for t in texts:
            enc = self.tok.encode(t)
            ids = np.array([enc.ids], dtype=np.int64)
            mask = np.array([enc.attention_mask], dtype=np.int64)
            feed = {"input_ids": ids, "attention_mask": mask}
            if "token_type_ids" in self.inputs:
                feed["token_type_ids"] = np.zeros_like(ids)
            hidden = self.sess.run(None, feed)[0][0]          # (tokens, 384)
            m = mask[0][:, None].astype(np.float32)
            yield (hidden * m).sum(0) / max(m.sum(), 1.0)


def _hash_vec(text: str) -> np.ndarray:
    v = np.zeros(HASH_DIM, dtype=np.float32)
    for w in re.findall(r"\w+", text.lower()):
        h = int(hashlib.md5(w.encode()).hexdigest(), 16)
        v[h % HASH_DIM] += 1.0
    n = np.linalg.norm(v)
    return v / n if n else v


def embed(texts: list[str]) -> list[np.ndarray]:
    _load()
    if _mode in ("model", "small"):
        out = []
        for v in _model.embed(texts):
            v = np.asarray(v, dtype=np.float32)
            out.append(v / (np.linalg.norm(v) or 1.0))
        return out
    return [_hash_vec(t) for t in texts]


def mode() -> str:
    _load()
    return _mode
