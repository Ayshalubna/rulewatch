"""Shows which AI models your API key can use, and tests each one with a tiny request.

    python -m rulewatch.models
"""
import sys
import time

from . import config


def main():
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    if not config.LLM_API_KEY:
        print("No API key in .env")
        return
    from openai import OpenAI
    client = OpenAI(api_key=config.LLM_API_KEY, base_url=config.LLM_BASE_URL, timeout=60)
    ids = sorted(m.id for m in client.models.list().data)
    print("MODELS AVAILABLE:", ", ".join(ids))
    skip = ("whisper", "tts", "guard", "playai", "orpheus", "distil", "prompt-guard", "compound")
    for mid in ids:
        if any(s in mid.lower() for s in skip):
            continue
        t0 = time.time()
        try:
            r = client.chat.completions.create(
                model=mid, temperature=0, max_tokens=40, response_format={"type": "json_object"},
                messages=[{"role": "system", "content": "Answer only with JSON."},
                          {"role": "user", "content": 'Return {"ok": true}'}])
            print(f"OK   {mid}  {time.time() - t0:.1f}s  {r.choices[0].message.content[:40]!r}")
        except Exception as e:
            print(f"FAIL {mid}  {str(e)[:160]}")


if __name__ == "__main__":
    main()
