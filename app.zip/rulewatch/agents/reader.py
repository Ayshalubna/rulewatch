"""READER AGENT
Reads a rule document from start to end:
  1. pulls out all the text (PDF pages or web-page sections) and saves it for search
  2. reads the document SECTION BY SECTION and extracts the concrete rules from each part
  3. combines everything into one clear summary in English and Arabic, with the top rules and page numbers
"""
import json
from .. import config, embed, llm, store
from ..pdf_text import read_any, chunk_pages

SECTION_CHARS = 6000

SYSTEM = """You are a UAE real estate regulation analyst.
You read official documents from Dubai Land Department (DLD), RERA, VARA and Dubai legislation.
Explain them in very simple English that a busy manager understands.
Never invent rules. Only use what is in the text."""


def _keyword_topics(text: str) -> list[str]:
    text = text.lower()
    found = [t for t, words in config.TOPIC_HINTS.items() if sum(text.count(w) for w in words) >= 2]
    return found or ["other"]


def _sections(pages: list[tuple[int, str]]) -> list[str]:
    """Groups pages into sections of ~7,000 characters, keeping page markers."""
    sections, cur = [], ""
    for p, t in pages:
        piece = f"\n[Page {p}]\n{t}"
        if cur and len(cur) + len(piece) > SECTION_CHARS:
            sections.append(cur)
            cur = ""
        cur += piece[: SECTION_CHARS * 2]
    if cur:
        sections.append(cur)
    return sections


def _pick_sections(sections: list[str]) -> list[str]:
    """If a document is very long, read an even spread of sections across the whole document."""
    n = config.MAX_SECTIONS_PER_DOC
    if len(sections) <= n:
        return sections
    step = len(sections) / n
    return [sections[int(i * step)] for i in range(n)]


def _extract_rules(title: str, section: str) -> list[dict]:
    def mock():
        line = section.strip().split("\n")[1] if "\n" in section.strip() else section[:150]
        page = section.split("[Page ")[1].split("]")[0] if "[Page " in section else "1"
        return {"rules": [{"rule": line[:160], "page": page, "who": "all"}]}
    out = llm.chat_json(SYSTEM, f"""Document: {title}
Part of the document:
{section}

List the concrete rules, requirements, prohibitions, deadlines, fees or penalties in this part.
Skip definitions and general background. Return JSON:
{{"rules": [{{"rule": "one rule in simple words", "page": <page number from the [Page N] marker>,
              "who": "who must follow it (brokers, developers, landlords, tenants, token issuers...)"}}]}}
Maximum 8 rules. If there are no real rules in this part, return {{"rules": []}}.""", mock=mock, fast=True)
    return [r for r in out.get("rules", []) if isinstance(r, dict) and r.get("rule")]


def _final_summary(title: str, rules: list[dict], opening: str, topics_hint: list[str]) -> dict:
    def mock():
        return {"title": title, "summary_en": f"[Demo summary] {opening[:200]}",
                "summary_ar": "[ملخص تجريبي] هذا المستند يحتوي على قواعد عقارية.",
                "key_points": rules[:8], "topics": topics_hint}
    return llm.chat_json(SYSTEM, f"""Document title: {title}
Opening text: {opening[:1500]}

Rules found while reading the whole document:
{json.dumps(rules[:60], ensure_ascii=False)}

Return JSON:
{{"title": "short clear title",
  "summary_en": "3 short simple sentences: what this document is, who it applies to, and what it requires",
  "summary_ar": "the same summary in Arabic",
  "key_points": [{{"rule": "...", "page": <page>}}],
  "topics": [choose from {config.TOPICS}]}}
key_points = the 8 most important rules for companies, from the list above (keep their page numbers).""", mock=mock)


def read_document(doc_id: int, run_id: str) -> bool:
    doc = store.get_document(doc_id)
    store.log(run_id, "Reader", f"Reading '{doc['title'][:80]}'")
    try:
        pages = read_any(doc["file_path"], doc.get("kind") or "pdf")
    except Exception as e:
        store.update_document(doc_id, status="failed")
        store.log(run_id, "Reader", f"Could not read document: {e}")
        return False
    if not pages or sum(len(t) for _, t in pages) < 100:
        store.update_document(doc_id, status="failed")
        store.log(run_id, "Reader", "No text found (maybe a scanned image). Marked as failed.")
        return False

    # 1) save every piece for search
    chunks = chunk_pages(pages)
    vectors = embed.embed([t for _, t in chunks])
    store.add_chunks(doc_id, [(p, t, v) for (p, t), v in zip(chunks, vectors)])
    unit = "sections" if doc.get("kind") == "html" else "pages"
    store.log(run_id, "Reader", f"{len(pages)} {unit}, {len(chunks)} searchable pieces saved")

    # 2) read the document part by part
    sections = _sections(pages)
    picked = _pick_sections(sections)
    rules, failed_parts = [], 0
    for i, s in enumerate(picked, start=1):
        try:
            rules += _extract_rules(doc["title"], s)
        except Exception as e:
            failed_parts += 1
            store.log(run_id, "Reader", f"Part {i} skipped: {str(e)[:140]}")
    note = "" if len(picked) == len(sections) else f" (spread across all {len(sections)} parts)"
    store.log(run_id, "Reader", f"Read {len(picked)} part(s){note}, found {len(rules)} rules")

    # 3) combine into one summary
    full_text = " ".join(t for _, t in pages)
    if failed_parts == len(picked) or (failed_parts > len(picked) // 2 and not rules):
        store.update_document(doc_id, status="new")
        store.log(run_id, "Reader", "AI limits reached while reading. Will finish this document on the next run.")
        return False
    try:
        out = _final_summary(doc["title"], rules, pages[0][1], _keyword_topics(full_text))
    except Exception as e:
        store.update_document(doc_id, status="new")
        store.log(run_id, "Reader", f"Summary not written ({str(e)[:120]}). Will retry on the next run.")
        return False
    topics = [t for t in out.get("topics", []) if t in config.TOPICS] or _keyword_topics(full_text)
    store.update_document(doc_id,
                          title=(out.get("title") or doc["title"])[:200],
                          summary_en=out.get("summary_en", ""),
                          summary_ar=out.get("summary_ar", ""),
                          key_points=(out.get("key_points") or rules)[:8],
                          topics=topics,
                          status="read")
    store.log(run_id, "Reader", f"Summary written. Topics: {', '.join(topics)}")
    return True
