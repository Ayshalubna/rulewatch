"""WATCHER AGENT
Checks every official source, finds rule documents (PDFs and web pages),
spots NEW documents and UPDATED versions, and downloads only what changed.

Source kinds:
  listing   page with many document links
  crawl     start page + one level of linked pages (e.g. every VARA rulebook page)
  document  one fixed official document, re-checked for changes
"""
import hashlib
import re
import time
from datetime import datetime, timedelta
from pathlib import Path
from urllib.parse import urljoin, urlparse, unquote

import requests
from bs4 import BeautifulSoup

from .. import config, store

MAX_BYTES = 40 * 1024 * 1024
MAX_CHILD_PAGES = 40
POLITE_DELAY = 0.6  # seconds between requests to the same site
SESSION = requests.Session()
SESSION.headers.update({"User-Agent": config.USER_AGENT, "Accept-Language": "en"})


# ---------------- helpers ----------------
def _safe_name(url: str, ext: str) -> str:
    name = unquote(Path(urlparse(url).path).name) or "document"
    name = re.sub(r"[^\w\-. ]", "_", Path(name).stem)[:70]
    return hashlib.md5(url.encode()).hexdigest()[:8] + "_" + name + ext


def _get(url: str, timeout=45) -> requests.Response:
    r = SESSION.get(url, timeout=timeout)
    r.raise_for_status()
    return r


def _is_pdf(url: str) -> bool:
    return ".pdf" in url.lower()


def _is_image(url: str) -> bool:
    return bool(re.search(r"\.(jpe?g|png|gif)(\?|$)", url.lower()))


def find_links(html: str, page_url: str) -> list[dict]:
    soup = BeautifulSoup(html, "html.parser")
    seen, links = set(), []
    for a in soup.find_all("a", href=True):
        href = urljoin(page_url, a["href"].strip()).split("#")[0]
        if not href.startswith("http") or href in seen:
            continue
        seen.add(href)
        text = " ".join(a.get_text(" ", strip=True).split())
        title = text if len(text) > 3 else unquote(Path(urlparse(href).path).stem).replace("_", " ")
        links.append({"url": href, "title": title[:200]})
    return links


def find_pdf_links(html: str, page_url: str) -> list[dict]:
    return [l for l in find_links(html, page_url) if _is_pdf(l["url"])]


_VERSION = re.compile(r"[_-](?:ver|v)(\d+)(?=\.pdf)", re.I)


def latest_versions(links: list[dict]) -> list[dict]:
    """Keep only the newest version of each file, e.g. ..._VER3.pdf vs ..._VER20250619.pdf."""
    best = {}
    for l in links:
        m = _VERSION.search(l["url"])
        key = _VERSION.sub("", l["url"]) if m else l["url"]
        ver = int(m.group(1)) if m else 0
        if key not in best or ver > best[key][0]:
            best[key] = (ver, l)
    return [v[1] for v in best.values()]


def html_to_text(html: str) -> tuple[str, str]:
    """Main readable text of a web page, split into sections at headings. Returns (title, text)."""
    soup = BeautifulSoup(html, "html.parser")
    for tag in soup(["script", "style", "nav", "header", "footer", "noscript", "form", "aside"]):
        tag.decompose()
    title = (soup.title.get_text(strip=True) if soup.title else "")[:200]
    main = soup.find("main") or soup.find("article") or soup.body or soup
    parts, section = [], 1
    article = re.compile(r"^(?:Article|Clause)\s*\(?(\d{1,3})\)?\b", re.I)
    for el in main.find_all(["h1", "h2", "h3", "h4", "p", "li", "td"]):
        if el.find(["p", "li", "td"]):  # avoid counting nested text twice
            continue
        txt = " ".join(el.get_text(" ", strip=True).split())
        if not txt:
            continue
        m = article.match(txt)
        if m:  # laws: one section per article, numbered like the article
            section = int(m.group(1))
            parts.append(f"\n[Section {section}] {txt}")
        elif el.name in ("h1", "h2", "h3", "h4"):
            section += 1
            parts.append(f"\n[Section {section}] {txt}")
        else:
            parts.append(txt)
    text = "\n".join(parts).strip()
    if len(text) < 200:  # page without structure: fall back to all text
        text = main.get_text("\n", strip=True)
    return title, text


def download(url: str) -> tuple[str, str, str, str]:
    """Download a document. Returns (file_path, sha256, kind, title_hint)."""
    r = SESSION.get(url, timeout=90, stream=True)
    r.raise_for_status()
    data = b""
    for part in r.iter_content(64 * 1024):
        data += part
        if len(data) > MAX_BYTES:
            raise ValueError("file too large")
    ctype = r.headers.get("content-type", "").lower()
    if data.startswith(b"%PDF"):
        path = config.PDF_DIR / _safe_name(url, ".pdf")
        path.write_bytes(data)
        return str(path), hashlib.sha256(data).hexdigest(), "pdf", ""
    if "html" in ctype or data.lstrip()[:15].lower().startswith((b"<!doctype", b"<html")):
        title, text = html_to_text(data.decode(r.encoding or "utf-8", errors="ignore"))
        if len(text) < 200:
            raise ValueError("page has almost no text (it may need JavaScript)")
        path = config.PDF_DIR / _safe_name(url, ".txt")
        path.write_text(text, encoding="utf-8")
        return str(path), hashlib.sha256(text.encode()).hexdigest(), "html", title
    raise ValueError(f"not a PDF or web page ({ctype or 'unknown type'})")


def _due_for_recheck(doc: dict) -> bool:
    if not doc.get("last_checked"):
        return True
    last = datetime.strptime(doc["last_checked"], "%Y-%m-%d %H:%M:%S")
    return datetime.now() - last > timedelta(days=config.RECHECK_DAYS)


def _fetch_document(link: dict, source: dict, run_id: str) -> int | None:
    """Download a document if it is new or due for a re-check. Returns doc id if new/changed."""
    known = store.get_document_by_url(link["url"])
    if known and not _due_for_recheck(known):
        return None
    try:
        path, sha, kind, title_hint = download(link["url"])
    except Exception as e:
        store.log(run_id, "Watcher", f"Could not download '{link['title'][:60]}': {e}")
        return None
    title = link["title"] if len(link["title"]) > 5 else (title_hint or link["title"])
    doc_id = store.add_document(link["url"], title, source["regulator"], source["url"], sha, path, kind)
    doc = store.get_document(doc_id)
    if doc["status"] != "new":
        return None  # same content as before
    word = "UPDATED version of" if doc["change_type"] == "updated" else "New"
    store.log(run_id, "Watcher", f"{word} rule document: {title[:90]}")
    return doc_id


# ---------------- per source kind ----------------
def _collect_listing(source, run_id) -> list[dict]:
    resp = _get(source["url"])
    links = find_links(resp.text, source["url"])
    images = [l for l in links if _is_image(l["url"])]
    docs = [l for l in links if _is_pdf(l["url"])]
    if images:
        store.log(run_id, "Watcher", f"Skipped {len(images)} image-only circulars (JPG). Add them as PDFs if needed.")
    return docs


def _collect_crawl(source, run_id) -> list[dict]:
    resp = _get(source["url"])
    links = find_links(resp.text, source["url"])
    docs = [l for l in links if _is_pdf(l["url"])]
    pattern = re.compile(source.get("follow") or r"$^")
    children = [l for l in links if pattern.search(l["url"]) and not _is_pdf(l["url"]) and l["url"] != source["url"]]
    children = children[:MAX_CHILD_PAGES]
    store.log(run_id, "Watcher", f"Following {len(children)} linked pages")
    for child in children:
        time.sleep(POLITE_DELAY)
        try:
            for l in find_links(_get(child["url"]).text, child["url"]):
                if _is_pdf(l["url"]):
                    if len(l["title"]) < 18 or re.search(r"download|version|current|here", l["title"], re.I):
                        l["title"] = child["title"]   # use the rulebook name, not 'Download'
                    docs.append(l)
        except Exception as e:
            store.log(run_id, "Watcher", f"Could not open {child['url']}: {e}")
    if source.get("latest_only"):
        docs = latest_versions(docs)
    uniq = {d["url"]: d for d in docs}
    return list(uniq.values())


def check_source(source: dict, run_id: str, budget: list[int]) -> list[int]:
    """budget is a one-item list so all sources share the same download limit."""
    store.log(run_id, "Watcher", f"Checking {source['name']}")
    try:
        if source["kind"] == "document":
            candidates = [{"url": source["url"], "title": source["name"]}]
        elif source["kind"] == "crawl":
            candidates = _collect_crawl(source, run_id)
        else:
            candidates = _collect_listing(source, run_id)
    except Exception as e:
        store.set_source_status(source["url"], f"error: {str(e)[:120]}")
        store.log(run_id, "Watcher", f"Could not open this source: {e}. Will try again next run.")
        return []

    store.save_snapshot(source["url"], [c["url"] for c in candidates])
    unseen = [c for c in candidates if not store.get_document_by_url(c["url"])]
    store.log(run_id, "Watcher", f"{len(candidates)} documents listed, {len(unseen)} never seen before")
    # new documents first, then re-checks of known ones
    ordered = unseen + [c for c in candidates if c not in unseen]
    new_ids = []
    for c in ordered:
        if budget[0] <= 0:
            store.log(run_id, "Watcher", "Download limit for this run reached. The rest will be done next run.")
            break
        doc_id = _fetch_document(c, source, run_id)
        if doc_id:
            new_ids.append(doc_id)
            budget[0] -= 1
        time.sleep(POLITE_DELAY)
    store.set_source_status(source["url"], f"ok · {len(candidates)} docs · {len(new_ids)} new/changed")
    return new_ids


# ---------------- manual upload ----------------
def add_local_pdf(file_bytes: bytes, filename: str, regulator: str, source_url: str = "", title: str = "") -> int:
    """For PDFs you download yourself (or when a site blocks automatic access)."""
    sha = hashlib.sha256(file_bytes).hexdigest()
    url = source_url.strip() or f"local://{sha[:16]}/{filename}"
    path = config.PDF_DIR / _safe_name(url, ".pdf")
    path.write_bytes(file_bytes)
    return store.add_document(url, title.strip() or Path(filename).stem.replace("_", " "),
                              regulator, "uploaded", sha, str(path), "pdf")
