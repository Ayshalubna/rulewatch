"""PLAN CHECK AGENTS
- Planner:    breaks the company's plan into actions and search questions
- Retriever:  finds the rule passages that matter (meaning + keyword search)
- Checker:    gives each action a 🟢🟡🔴 signal, citing the exact passages
- Verifier:   the citation guard. Removes any claim that doesn't point to a real passage
              (this stops the AI from making up rules)
- Reporter:   writes the final answer in English or Arabic
"""
import json
from .. import config, embed, llm, store

ORDER = {"green": 0, "yellow": 1, "red": 2}


# ---------- Planner ----------
def plan_analyzer(plan: str, company_type: str, run_id: str) -> dict:
    def mock():
        sentences = [s.strip() for s in plan.replace("\n", ". ").split(".") if len(s.strip()) > 10]
        return {"actions": sentences[:4] or [plan[:200]],
                "queries": sentences[:4] or [plan[:200]],
                "topics": config.COMPANY_TYPES.get(company_type, [])[:2]}
    out = llm.chat_json(
        "You help UAE real estate companies check their plans against regulations.",
        f"""Company type: {company_type}
Plan: {plan}

Return JSON:
{{"actions": ["each separate thing the company plans to do, max 4"],
  "queries": ["3-5 short search questions to find the relevant rules, in English"],
  "topics": [choose from {config.TOPICS}]}}""",
        mock=mock, fast=True)
    store.log(run_id, "Planner", f"Found {len(out.get('actions', []))} planned actions to check")
    return out


# ---------- Retriever ----------
def retrieve(queries: list[str], run_id: str, per_query=3, limit=10, focus_topics=None, strong_topics=None) -> list[dict]:
    """Searches each question separately and takes the best passages from each in turn (round-robin),
    so every planned action gets its own evidence. focus_topics gives a small boost to documents on the
    topics this business type cares about. At most 3 passages come from any one document."""
    vectors = embed.embed(queries) if queries else []
    topics_of = store.doc_topics_map()
    ranked = []
    for q, v in zip(queries, vectors):
        hits = store.search(v, q, k=25)
        for h in hits:
            h["topics"] = topics_of.get(h["doc_id"], [])
            if focus_topics and set(h["topics"]) & set(focus_topics):
                h["score"] += 0.06
            if strong_topics and set(h["topics"]) & set(strong_topics):
                h["score"] += 0.08   # the plan text itself names this topic
        hits.sort(key=lambda h: h["score"], reverse=True)
        ranked.append(hits)

    evidence, seen, per_doc = [], set(), {}
    for rnd in range(per_query):
        for hits in ranked:
            for h in hits:
                if h["chunk_id"] in seen or per_doc.get(h["doc_id"], 0) >= 3:
                    continue
                evidence.append(h)
                seen.add(h["chunk_id"])
                per_doc[h["doc_id"]] = per_doc.get(h["doc_id"], 0) + 1
                break
            if len(evidence) >= limit:
                break
        if len(evidence) >= limit:
            break
    for i, e in enumerate(evidence, start=1):
        e["eid"] = f"E{i}"
    titles = list(dict.fromkeys(e["title"] for e in evidence))
    store.log(run_id, "Retriever", f"Pulled {len(evidence)} rule passages from {len(titles)} documents: "
              + "; ".join(t[:60] for t in titles[:4]))
    return evidence


def _evidence_block(evidence: list[dict]) -> str:
    return "\n\n".join(f"[{e['eid']}] ({e['regulator']} — {e['title']}, {'section' if e.get('kind') == 'html' else 'page'} {e['page']})\n{e['text']}"
                       for e in evidence)


# ---------- Checker ----------
def check(plan: str, company_type: str, activities: str, actions: list[str], evidence: list[dict], run_id: str) -> list[dict]:
    def mock():
        out = []
        for a in actions:
            words = set(a.lower().split())
            best = max(evidence, key=lambda e: len(words & set(e["text"].lower().split())), default=None)
            risky = any(w in a.lower() for w in ("without", "no permit", "skip", "cash", "guarantee", "guaranteed"))
            out.append({"action": a, "signal": "red" if risky else "yellow" if best else "green",
                        "why": "[Demo] Compare this action with the cited rule.",
                        "evidence": [best["eid"]] if best else [],
                        "what_to_do": "[Demo] Read the cited passage and confirm with your compliance team."})
        return {"findings": out}

    out = llm.chat_json(
        """You are a strict UAE real estate compliance checker (DLD, RERA, VARA).
Use ONLY the rule passages given (some passages are in Arabic: read them and explain in English).
A general requirement applies to every action it covers. Example: if a passage says buyer payments for off-plan
units must go into the project escrow account, then paying them into another account breaks that rule (red).
Every red or yellow finding MUST cite passage ids like "E2".
If a passage relates to an action and the action follows what it requires, the signal is "green": say which rule
it follows and cite that passage too. Good plans should come back green, not "not covered".
Only if truly no passage is about the subject of an action, use signal "yellow" with
why = "Not covered by the rules loaded so far" and no evidence.
Do not guess rules from memory. Simple English.""",
        f"""Company type: {company_type}
What the company does: {activities or 'not given'}
Plan: {plan}
Actions to check: {json.dumps(actions, ensure_ascii=False)}

Rule passages:
{_evidence_block(evidence)}

Return JSON:
{{"findings": [{{"action": "...", "signal": "green | yellow | red",
  "why": "1-2 sentences, what the rule says about this action",
  "evidence": ["E1"], "what_to_do": "one concrete next step"}}]}}
red = looks against a rule; yellow = allowed only if a condition is met, or unclear; green = no problem found.""",
        mock=mock)
    findings = out.get("findings", [])
    store.log(run_id, "Checker", "Signals: " + ", ".join(f.get("signal", "?") for f in findings))
    return findings


# ---------- Verifier (citation guard) ----------
def verify(findings: list[dict], evidence: list[dict], run_id: str) -> list[dict]:
    by_id = {e["eid"]: e for e in evidence}
    fixed, removed = [], 0
    for f in findings:
        sig = str(f.get("signal", "yellow")).lower()
        sig = sig if sig in ORDER else "yellow"
        cited = [c for c in f.get("evidence", []) if c in by_id]
        removed += len(f.get("evidence", [])) - len(cited)
        if sig in ("red", "yellow") and not cited and "not covered" not in str(f.get("why", "")).lower():
            sig = "yellow"
            f["why"] = "The AI flagged this but could not point to a loaded rule. Please check manually."
        f["signal"] = sig
        f["sources"] = [{"eid": c, "title": by_id[c]["title"], "page": by_id[c]["page"],
                         "url": by_id[c]["url"], "regulator": by_id[c]["regulator"], "kind": by_id[c].get("kind"),
                         "quote": by_id[c]["text"][:350]} for c in cited]
        fixed.append(f)
    store.log(run_id, "Verifier", f"Checked all citations. Removed {removed} citation(s) that did not match a real rule passage")
    return fixed


# ---------- Reporter ----------
def report(findings: list[dict], language: str, run_id: str) -> dict:
    overall = max((f["signal"] for f in findings), key=lambda s: ORDER[s], default="green")
    counts = {s: sum(f["signal"] == s for f in findings) for s in ORDER}

    def mock():
        return {"summary": f"[Demo] {counts['red']} red, {counts['yellow']} yellow, {counts['green']} green."}
    lang = "Arabic" if language == "ar" else "simple English"
    out = llm.chat_json(
        "You write short compliance summaries for busy managers.",
        f"""Findings: {json.dumps([{k: f[k] for k in ('action', 'signal', 'why', 'what_to_do')} for f in findings], ensure_ascii=False)}
Write a 2-3 sentence overall summary in {lang}. Keep each finding's meaning exactly: a red finding is something
the company must NOT do as planned; say what the rule requires instead. Return JSON: {{"summary": "..."}}""",
        mock=mock, fast=True)
    store.log(run_id, "Reporter", f"Overall signal: {overall.upper()}")
    return {"overall": overall, "counts": counts, "summary": out.get("summary", "")}


# ---------- Ask the rules (Q&A) ----------
def ask(question: str, language: str, run_id: str) -> dict:
    evidence = retrieve([question], run_id, per_query=6, limit=6)
    if not evidence:
        return {"answer": "No rules are loaded yet. Run the Watcher or upload a PDF first.", "sources": []}

    def mock():
        return {"answer": f"[Demo answer] The closest rule passage is {evidence[0]['eid']}.", "evidence": [evidence[0]["eid"]]}
    lang = "Arabic" if language == "ar" else "simple English"
    out = llm.chat_json(
        """Answer questions about UAE real estate rules using ONLY the passages given.
Cite passage ids like [E1] in the answer. If the passages don't answer it, say so clearly.""",
        f"""Question: {question}

Passages:
{_evidence_block(evidence)}

Return JSON: {{"answer": "answer in {lang} with [E#] citations", "evidence": ["E1"]}}""",
        mock=mock)
    by_id = {e["eid"]: e for e in evidence}
    cited = [c for c in out.get("evidence", []) if c in by_id]
    store.log(run_id, "Verifier", f"Answer cites {len(cited)} real passage(s)")
    return {"answer": out.get("answer", ""),
            "sources": [{"eid": c, "title": by_id[c]["title"], "page": by_id[c]["page"], "url": by_id[c]["url"],
                         "regulator": by_id[c]["regulator"], "kind": by_id[c].get("kind"), "quote": by_id[c]["text"][:350]} for c in cited]}
