"""ALERT AGENT
Sends each company only the new rules that affect it (in the app, and by email if set up).
"""
import requests
from .. import config, store

ICON = {"high": "🔴", "medium": "🟡", "low": "🟢"}


def _send_email(to: str, subject: str, body: str) -> bool:
    if not (config.RESEND_API_KEY and to):
        return False
    try:
        r = requests.post("https://api.resend.com/emails",
                          headers={"Authorization": f"Bearer {config.RESEND_API_KEY}"},
                          json={"from": config.ALERT_FROM_EMAIL, "to": [to], "subject": subject,
                                "html": body.replace("\n", "<br>")}, timeout=20)
        return r.status_code < 300
    except Exception:
        return False


def notify(doc_id: int, run_id: str) -> int:
    doc = store.get_document(doc_id)
    sent = 0
    for company in store.list_companies():
        todo = doc["affects"].get(company["type"])
        if not todo:
            continue
        icon = ICON.get(doc["severity"], "🟡")
        what = "UPDATED" if doc.get("change_type") == "updated" else "New"
        message = (f"{icon} {what} {doc['regulator']} rule: {doc['title']}\n"
                   f"What it says: {doc['summary_en']}\n"
                   f"What {company['name']} should do: {todo}\n"
                   f"Official source: {doc['url']}")
        alert_id = store.add_alert(company["id"], doc_id, message)
        if _send_email(company["email"], f"{icon} RuleWatch: new {doc['regulator']} rule affects you", message):
            store.mark_emailed(alert_id)
        sent += 1
        store.log(run_id, "Alert", f"Alert sent to {company['name']} ({company['type']})")
    if sent == 0:
        store.log(run_id, "Alert", "No registered company is affected by this rule")
    return sent
