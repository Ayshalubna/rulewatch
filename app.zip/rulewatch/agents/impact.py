"""IMPACT AGENT
Decides which types of company a new rule affects, how serious it is,
and what each type of company should do.
"""
import json
from .. import config, llm, store

SYSTEM = """You are a compliance advisor for UAE real estate companies.
Decide who a regulation affects and what they must do. Be practical and specific.
Only use the information given. If a company type is not affected, leave it out."""


def _mock(doc):
    affects = {ct: f"Review this document: it covers {', '.join(doc['topics'])}."
               for ct, topics in config.COMPANY_TYPES.items() if set(topics) & set(doc["topics"])}
    sev = "high" if {"advertising", "tokenization & virtual assets", "off-plan & escrow"} & set(doc["topics"]) else "medium"
    return {"affects": affects, "severity": sev}


def assess(doc_id: int, run_id: str) -> dict:
    doc = store.get_document(doc_id)
    prompt = f"""Regulation: {doc['title']} (regulator: {doc['regulator']})
Summary: {doc['summary_en']}
Key rules: {json.dumps(doc['key_points'], ensure_ascii=False)}
Topics: {doc['topics']}

Company types and what they usually care about:
{json.dumps(config.COMPANY_TYPES, indent=1)}

Return JSON:
{{
  "affects": {{"<company type exactly as written above>": "1-2 sentences: what this company type must do or check"}},
  "severity": "high | medium | low"
}}
high = can lead to fines or stopping business if ignored; low = general information."""
    out = llm.chat_json(SYSTEM, prompt, mock=lambda: _mock(doc))
    affects = {k: v for k, v in (out.get("affects") or {}).items() if k in config.COMPANY_TYPES}
    severity = out.get("severity", "medium") if out.get("severity") in ("high", "medium", "low") else "medium"
    store.update_document(doc_id, affects=affects, severity=severity)
    who = ", ".join(affects) or "no company type"
    store.log(run_id, "Impact", f"'{doc['title']}' → severity {severity}; affects: {who}")
    return affects
