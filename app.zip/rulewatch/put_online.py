"""Puts RuleWatch online as a Hugging Face Space (free), in one go.

    python -m rulewatch.put_online

What it does:
 1. asks for your Hugging Face access token (you paste it; it is not saved anywhere)
 2. creates the Space  <your-name>/rulewatch  (Docker)
 3. copies your AI settings from .env into the Space as secrets
 4. uploads the `rulewatch_online` folder (code + website + rules already read)
 5. prints your live link and writes it to online_info.txt
"""
import getpass
import os
import secrets
import sys
from pathlib import Path

from dotenv import dotenv_values
from huggingface_hub import HfApi

ROOT = Path(__file__).resolve().parent.parent
PKG = ROOT / "rulewatch_online"
SPACE_NAME = "rulewatch"


def main():
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    if not (PKG / "Dockerfile").exists():
        raise SystemExit("The rulewatch_online folder is missing. Ask Claude to build it again.")
    env = dotenv_values(ROOT / ".env")
    if not env.get("LLM_API_KEY"):
        raise SystemExit("No LLM_API_KEY in .env. Add your Groq key there first.")

    tok_file = ROOT / "hf_token.txt"
    token = os.getenv("HF_TOKEN") or ""
    if not token and tok_file.exists():
        token = tok_file.read_text(encoding="utf-8", errors="ignore").strip()
    if not token:
        print("\nPaste your Hugging Face token (it starts with hf_). You will not see it while pasting.")
        print("Press Ctrl+V (or right-click once), then press Enter.\n")
        token = getpass.getpass("Token: ").strip()
    api = HfApi(token=token)
    try:
        user = api.whoami()["name"]
    except Exception as e:
        raise SystemExit(f"That token did not work ({str(e)[:120]}). Make a new one with WRITE access and try again.")
    repo = f"{user}/{SPACE_NAME}"
    print(f"Logged in as {user}. Creating Space {repo} ...")
    api.create_repo(repo_id=repo, repo_type="space", space_sdk="docker", exist_ok=True)

    admin = env.get("ADMIN_TOKEN") or secrets.token_urlsafe(12)
    settings = {
        "LLM_PROVIDER": env.get("LLM_PROVIDER") or "groq",
        "LLM_API_KEY": env["LLM_API_KEY"],
        "ADMIN_TOKEN": admin,
    }
    for k in ("LLM_BASE_URL", "LLM_MODEL", "LLM_FAST_MODEL", "LLM_FALLBACK_MODELS"):
        if env.get(k):
            settings[k] = env[k]
    for k, v in settings.items():
        api.add_space_secret(repo_id=repo, key=k, value=v)
    print("Saved your AI settings as private Space secrets.")

    print("Uploading RuleWatch (about 8 MB) ...")
    api.upload_folder(folder_path=str(PKG), repo_id=repo, repo_type="space",
                      ignore_patterns=["*.db-journal", "__pycache__/*", "**/__pycache__/*", "make_deploy.py"],
                      commit_message="Put RuleWatch online")

    if tok_file.exists():
        tok_file.unlink()   # don't leave the secret token lying around
    url = f"https://{user.lower().replace('_', '-')}-{SPACE_NAME}.hf.space"
    info = (f"RuleWatch live link : {url}\n"
            f"Space page          : https://huggingface.co/spaces/{repo}\n"
            f"Admin token (lock button on the site): {admin}\n")
    (ROOT / "online_info.txt").write_text(info, encoding="utf-8")
    print("\n" + "=" * 60 + "\nDONE! RuleWatch is going online.\n" + info +
          "The first start takes about 5-8 minutes (Hugging Face builds it).\n"
          "This is also saved in online_info.txt\n" + "=" * 60)


if __name__ == "__main__":
    main()
