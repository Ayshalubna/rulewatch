"""Downloads the Dubai photography used by the website (free Unsplash photos) into frontend/dist/img.
Runs once; later runs skip photos already downloaded.

    python -m rulewatch.fetch_images
"""
import re
import sys
from pathlib import Path
from urllib.parse import urlencode, urlparse, parse_qsl, urlunparse

import requests

OUT = Path(__file__).resolve().parent.parent / "frontend" / "dist" / "img"
# Unsplash photo IDs: Dubai skyline / towers at night
CANDIDATES = ["x_QNgW9RqLc", "UaJVcPS-9Lw", "l4rokkLcx_E", "QDsa_5uXCYw", "j-nRfGUHswQ",
              "-O5ZRtXXB7g", "pLstF_rW-NI", "EX-DhiCkjyA", "NJEUWwtvW8s", "mb72tt51npQ"]


UA = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130 Safari/537.36"}


def _image_url(pid: str) -> str | None:
    # 1) the official download link (redirects to the image CDN)
    try:
        r = requests.get(f"https://unsplash.com/photos/{pid}/download?force=true", allow_redirects=False, timeout=30, headers=UA)
        if r.headers.get("location", "").startswith("https://images.unsplash.com"):
            return r.headers["location"]
        print(f"  {pid}: download link gave {r.status_code}")
    except Exception as e:
        print(f"  {pid}: download link failed ({str(e)[:60]})")
    # 2) the photo page's preview image
    try:
        html = requests.get(f"https://unsplash.com/photos/{pid}", timeout=30, headers=UA).text
        m = re.search(r'<meta[^>]+property="og:image"[^>]+content="([^"]+)"', html) or \
            re.search(r'(https://images\.unsplash\.com/photo-[^"?\s]+)', html)
        if m:
            return m.group(1).replace("&amp;", "&")
        print(f"  {pid}: no image found on the photo page")
    except Exception as e:
        print(f"  {pid}: photo page failed ({str(e)[:60]})")
    return None


def fetch(pid: str) -> bool:
    dst = OUT / f"cand_{pid}.jpg"
    if dst.exists() and dst.stat().st_size > 50_000:
        return True
    try:
        r = requests.get(f"https://unsplash.com/photos/{pid}/download?force=true", allow_redirects=True,
                         timeout=90, headers=UA)
        r.raise_for_status()
        if not r.headers.get("content-type", "").startswith("image"):
            print(f"  {pid}: not an image ({r.headers.get('content-type')}) at {r.url[:80]}")
            return False
        data = r.content
        try:  # shrink to web size
            from io import BytesIO
            from PIL import Image
            im = Image.open(BytesIO(data)).convert("RGB")
            im.thumbnail((2400, 2400))
            buf = BytesIO()
            im.save(buf, "JPEG", quality=80, optimize=True, progressive=True)
            data = buf.getvalue()
        except Exception as e:
            print(f"  {pid}: kept original size ({str(e)[:60]})")
        dst.write_bytes(data)
        print(f"  {pid}: {len(data) // 1024} KB")
        return True
    except Exception as e:
        print(f"  {pid}: failed ({str(e)[:100]})")
        return False


# Chosen photo (Dubai Marina at night, by Leon Macapagal on Unsplash), from Unsplash's public image server
HERO_CDN = "https://images.unsplash.com/photo-1661630804516-10393c1bb0a8?w=2400&q=80&fm=jpg&fit=max"


def fetch_cdn(url: str, name: str) -> bool:
    dst = OUT / name
    if dst.exists() and dst.stat().st_size > 50_000:
        return True
    try:
        r = requests.get(url, timeout=90, headers=UA)
        r.raise_for_status()
        if not r.headers.get("content-type", "").startswith("image"):
            print(f"  {name}: not an image")
            return False
        dst.write_bytes(r.content)
        print(f"  {name}: {len(r.content) // 1024} KB")
        return True
    except Exception as e:
        print(f"  {name}: failed ({str(e)[:100]})")
        return False


def main():
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    OUT.mkdir(parents=True, exist_ok=True)
    if (OUT / "hero.jpg").exists():
        return
    print("Downloading Dubai photography for the website...")
    if fetch_cdn(HERO_CDN, "hero.jpg"):
        print("Photos ready.")
        return
    ok = [p for p in CANDIDATES if fetch(p)]
    if ok:
        (OUT / "hero.jpg").write_bytes((OUT / f"cand_{ok[0]}.jpg").read_bytes())
        print("Photos ready.")


if __name__ == "__main__":
    main()
