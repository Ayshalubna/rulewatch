"""Starts the RuleWatch website on the first free port from 8000 and opens it in the browser.

    python -m rulewatch.serve
"""
import socket
import sys
import threading
import time
import webbrowser


def free_port(start=8000, tries=20) -> int:
    for port in range(start, start + tries):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            try:
                s.bind(("127.0.0.1", port))
                return port
            except OSError:
                continue
    raise SystemExit("No free port found between 8000 and 8020.")


def main():
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    import uvicorn
    port = free_port()
    url = f"http://localhost:{port}"
    print(f"\n  RuleWatch is running at {url}   (keep this window open; close it to stop)\n")
    threading.Thread(target=lambda: (time.sleep(2.5), webbrowser.open(url)), daemon=True).start()
    uvicorn.run("server:app", host="127.0.0.1", port=port, log_level="warning",
                reload=True, reload_dirs=["rulewatch"], reload_includes=["*.py"])


if __name__ == "__main__":
    main()
