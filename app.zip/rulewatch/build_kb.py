"""Load the official rules into RuleWatch (run on a machine with internet and a Groq key).

    python -m rulewatch.build_kb --max 30
"""
import argparse
import sys
import time

from . import config, llm, store
from .manager import run_watch


def main():
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    ap = argparse.ArgumentParser()
    ap.add_argument("--max", type=int, default=30, help="max new or changed documents to read")
    ap.add_argument("--reset-sources", action="store_true", help="replace saved sources with the default list")
    args = ap.parse_args()
    if llm.is_mock():
        print("No AI key found. Put your Groq key in the .env file (LLM_PROVIDER=groq).")
        return
    if args.reset_sources:
        store.reset_sources(config.DEFAULT_SOURCES)
    else:
        store.seed_sources(config.DEFAULT_SOURCES)
    print(f"Loading up to {args.max} rule documents with {config.LLM_MODEL}. This can take 20-40 minutes...\n")
    t0 = time.time()
    r = run_watch(max_new=args.max)
    for row in store.get_log(run_id=r["run_id"]):
        print(f"[{row['agent']}] {row['message']}")
    s = store.stats()
    read = sum(d["n"] for d in s["docs"] if d["status"] == "read")
    print(f"\nDone in {int(time.time() - t0) // 60} min. Documents read: {read}. Rule passages: {s['chunks']}.")
    print(f"AI calls: {llm.usage['calls']}, model switches: {llm.usage['fallbacks']}")


if __name__ == "__main__":
    main()
