"""Puts RuleWatch on the internet from this laptop, with a public https link (free, no account).

    python -m rulewatch.go_live

How: starts the RuleWatch website, then opens a free Cloudflare "quick tunnel" to it.
Anyone with the link (your phone, a recruiter's laptop) can use RuleWatch while this window is open.
Admin actions (Watcher, adding sources/businesses, quality tests) are locked with an admin token.
"""
import os
import re
import secrets
import socket
import subprocess
import sys
import threading
import time
import urllib.request
import webbrowser
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
TOOLS = ROOT / "tools"
CLOUDFLARED = TOOLS / "cloudflared.exe"
CF_URL = "https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-windows-amd64.exe"
INFO = ROOT / "online_link.txt"


def free_port(start=8100) -> int:
    for port in range(start, start + 50):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            try:
                s.bind(("127.0.0.1", port))
                return port
            except OSError:
                continue
    raise SystemExit("No free port found.")


def get_cloudflared():
    if CLOUDFLARED.exists() and CLOUDFLARED.stat().st_size > 1_000_000:
        return
    TOOLS.mkdir(exist_ok=True)
    print("Downloading Cloudflare tunnel tool (one time, about 60 MB) from github.com/cloudflare ...")
    urllib.request.urlretrieve(CF_URL, CLOUDFLARED)
    print("Downloaded.")


def admin_token() -> str:
    """Same admin token every time (kept in online_link.txt), only used for the public link."""
    if os.getenv("ADMIN_TOKEN"):
        return os.environ["ADMIN_TOKEN"]
    if INFO.exists():
        m = re.search(r"Admin token[^:]*:\s*(\S+)", INFO.read_text(encoding="utf-8"))
        if m:
            return m.group(1)
    return secrets.token_urlsafe(9)


def qr(url: str):
    try:
        import qrcode
        q = qrcode.QRCode(border=1)
        q.add_data(url)
        q.print_ascii(invert=True)
    except Exception:
        pass


def main():
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    os.chdir(ROOT)
    token = admin_token()
    os.environ["ADMIN_TOKEN"] = token          # public link: lock admin actions
    get_cloudflared()

    port = free_port()
    import uvicorn
    server = threading.Thread(target=lambda: uvicorn.run("server:app", host="127.0.0.1", port=port,
                                                         log_level="warning"), daemon=True)
    server.start()
    for _ in range(60):
        try:
            urllib.request.urlopen(f"http://127.0.0.1:{port}/api/meta", timeout=2)
            break
        except Exception:
            time.sleep(1)
    print(f"RuleWatch is running on this laptop (port {port}). Opening the public link ...")

    proc = subprocess.Popen([str(CLOUDFLARED), "tunnel", "--no-autoupdate", "--url", f"http://127.0.0.1:{port}"],
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
                            encoding="utf-8", errors="replace")
    url = None
    for line in proc.stdout:
        m = re.search(r"https://[a-z0-9-]+\.trycloudflare\.com", line)
        if m:
            url = m.group(0)
            break
    if not url:
        raise SystemExit("Could not open the public link. Check the internet and run go_live.bat again.")

    INFO.write_text(f"RuleWatch public link: {url}\nAdmin token (lock button on the site): {token}\n"
                    f"Works while the 'RuleWatch LIVE' window is open. The link changes each time you start it.\n",
                    encoding="utf-8")
    print("\n" + "=" * 64)
    print(f"  RuleWatch is LIVE:  {url}")
    print(f"  Admin token:        {token}")
    print("  Scan this with your phone camera:")
    qr(url)
    print("  Keep this window open. Close it to take RuleWatch offline.")
    print("  (Saved in online_link.txt)")
    print("=" * 64 + "\n")
    threading.Thread(target=lambda: (time.sleep(4), webbrowser.open(url)), daemon=True).start()
    for _ in proc.stdout:      # keep the tunnel running
        pass


if __name__ == "__main__":
    main()
